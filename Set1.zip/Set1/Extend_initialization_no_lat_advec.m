
clear
close all
clc

%% INPUT

% This version of the code is made specifically to extend an initialization
% run!

% Specify the set #
Set = 1;

% If this is set to 1, it will run the initialization period for the set #.
% In other words, no weak zone is introduced during the run. If this is
% set to 0, it will load the premade set # DEM and then introduce the weak
% zone.
Initialization_run = 1;

% This is the scenario # within the corresponding set. If this is an
% initialization run, then this value doesn't matter.
Scenario = 1;

%% READS INPUT FROM EXCEL FILE

Original_location = pwd;

% I am not changing the boundary conditions across model runs, so I just
% specify the conditions here. Having 'lr' makes tall walls along the
% western and eastern boundaries.
boundary_conditions = 'lr';

% Rock-uplift rate (m/yr)
U_rate_mpyr = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'B5');

% Positive means from W to E, negative means from E to W
lat_advection_rate_WtoE_mpyr = 0;
% lat_advection_rate_WtoE_mpyr = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'C5');

% Positive means from N to S, negative means from S to N
lat_advection_rate_NtoS_mpyr = 0;
% lat_advection_rate_NtoS_mpyr = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'D5');

xmax_value_m = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'E5');

ymax_value_m = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'F5');

% Also used for dy
dx_value_m = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'G5');

timestep_yrs = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'H5');

n_value = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'I5');
m_value = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'J5');
Kw_value = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'K5');

Initial_noise_scalar_m = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'P5');

plot_freq_yrs = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'R5');

if Initialization_run == 1
    
    save_freq_yrs = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'S5');
    
elseif Initialization_run ~= 1
    
    save_freq_yrs = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'S9');
    
end

% These are the number of timesteps between each intances of plotting and
% saving
plot_freq = ceil(plot_freq_yrs / timestep_yrs);
save_freq = ceil(save_freq_yrs / timestep_yrs);

A_cr_m2 = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'N5');

Diffusivity_m2pyr = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'M5');

Sc_value = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'O5');

K_weight_strong = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'L5');

max_Courant_val = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'V5');

save_Courant_grid_option = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'W5');

% If this is set to 1, the simulation will plot and save values at the time
% specified for time_early_check_yrs. This can be important for checking
% the Courant values so that a broken simulation doesn't wait until the
% first plotting / saving interval to exit the while loop.
early_check_Courant = 0;%xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'T5');

time_early_check_yrs = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'U5');

dt_shrink_factor = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'X5');

enable_plotting_during_run = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'Y5');

enable_saving_during_run = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'Z5');

implCFL_option = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'AA5');

parallel_option = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'AB5');

% INPUT SPECIFIC TO EACH SCENARIO
if Initialization_run == 1
    
    % This is changed to read the extended initialization duration
    model_duration_yrs = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'Q9');
    
    % This is used to load the premade DEM
    initialization_duration_yrs = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'Q5');
    
    model_duration_yrs = model_duration_yrs + initialization_duration_yrs;
    
    save_Kw_grid_option = 0;
    
    % This is the width of the weak zone in the y direction (i.e.,
    % north-south). The weak zone extends across the entire domain in the x
    % direction (i.e., east-west).
    Width_of_weak_zone_m_y_dir = 0;
    
    K_weight_weak = 0;
    
elseif Initialization_run == 0
    
    % This is used to load the premade DEM
    initialization_duration_yrs = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'Q5');
    
    model_duration_yrs = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'E12:E99');
    model_duration_yrs = model_duration_yrs(1,Scenario);
    
    save_Kw_grid_option = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'D12:D99');
    save_Kw_grid_option = save_Kw_grid_option(1,Scenario);
    
    % This is the width of the weak zone in the y direction (i.e.,
    % north-south). The weak zone extends across the entire domain in the x
    % direction (i.e., east-west).
    Width_of_weak_zone_m_y_dir = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'C12:C99');
    Width_of_weak_zone_m_y_dir = Width_of_weak_zone_m_y_dir(1,Scenario);
    
    K_weight_weak = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'B12:B99');
    K_weight_weak = K_weight_weak(1,Scenario);
    
end

% This is the time before the weak zone enters the domain (years). Right
% now, I have it set up so that this is either set really high so it isn't
% used (for initialization runs) or set to zero so the weak zone enters
% (for scenario runs).
if Initialization_run == 1
    
    time_before_weak_zone = model_duration_yrs * 10;
    
elseif Initialization_run == 0
    
    time_before_weak_zone = 0;
    
end

%% Make directories

if exist('Output','dir') == 0
    
    mkdir('Output');
    
end

Output_location = [pwd '\Output'];

cd(Output_location)

if Initialization_run == 1
    
    if exist(['Set' num2str(Set,'%.0f') '_Initialization'],'dir') == 0
        
        mkdir(['Set' num2str(Set,'%.0f') '_Initialization']);
        
    end
    
    Set_initialization_location = [pwd ['\Set' num2str(Set,'%.0f') '_Initialization\']];
    
    p.resultsdir = Set_initialization_location;
    
elseif Initialization_run == 0
    
    if exist(['Scenario_' num2str(Scenario,'%.0f')],'dir') == 0
        
        mkdir(['Scenario_' num2str(Scenario,'%.0f')]);
        
    end
    
    Scenario_location = [pwd ['\Scenario_' num2str(Scenario,'%.0f') '\']];
    
    p.resultsdir = Scenario_location;
    
    Set_initialization_location = [pwd ['\Set' num2str(Set,'%.0f') '_Initialization\']];
    
end

%% Initial Surface
% Generate random initial surface of 0 m � 50 m (or whatever
% initial_noise_scalar_m is set to).

dx=dx_value_m;%m
Lx=xmax_value_m;
Ly=ymax_value_m;
x=dx:dx:Lx;
y=dx:dx:Ly;

if Initialization_run == 1
    
    %     Z=zeros(numel(y),numel(x));
    %     Z(2:end-1,2:end-1) =rand(numel(y)-2,numel(x)-2) * Initial_noise_scalar_m;
    %
    %     H1=GRIDobj(x,y,Z);
    %     figure('units','normalized','outerposition',[0.1 0.1 .5 .5],'color','white');
    %     imageschs(H1);
    
    cd(Set_initialization_location)
    
    load(['Set' num2str(Set,'%.0f') '_ini_t_' num2str(initialization_duration_yrs / 1e3) '_kyr.mat'],'H1','current_time');
    figure('units','normalized','outerposition',[0.1 0.1 .5 .5],'color','white');
    imageschs(H1);
    
    current_time_prev = current_time;
    
elseif Initialization_run == 0
    
    cd(Set_initialization_location)
    
    load(['Set' num2str(Set,'%.0f') '_ini_t_' num2str(initialization_duration_yrs / 1e3) '_kyr.mat'],'H1');
    figure('units','normalized','outerposition',[0.1 0.1 .5 .5],'color','white');
    imageschs(H1);
    
end

%% Temporal domain
p.TimeSpan = model_duration_yrs;
p.TimeStep = timestep_yrs;

%% Vertical uplift
% Vertical uplift rates are considered here as a sequence of three
% tectonic configurations.
% Vertical uplift is inserted in TTLEM as an instance of GRIDobj
U = GRIDobj(H1);

%% FIRST uplift phase (second in users guide 3)
% A constant uplift over 10 Myr over the entire spatial domain at 1 mm/y
spat_u_1 = ones(size(U.Z,1), size(U.Z,2));
spat_u_1 = spat_u_1 * U_rate_mpyr;
spat_u_1(1,:) = 0; spat_u_1(end,:) = 0; spat_u_1(:,1) = 0; spat_u_1(:,end) = 0;
nbOfSteps1 = p.TimeSpan / p.TimeStep;
% U.Z(2:end-1,2:end-1,1:nbOfSteps1) = ...
%     repmat(spat_u_1(2:end-1,2:end-1),[1,1,nbOfSteps1]);
U.Z = spat_u_1;

%Display first spatial uplift pattern
figure('units','normalized','outerposition',[0.1 0.1 .5 .5],'color','white');
imagesc(spat_u_1)
colorbar
title('Vertical uplift pattern')

%% Lateral tectonic displacement
% We insert a tectonic shortening  field operational in two directions and
% temporally constant over the entire model simulation
p.shortening=true;
p.shortening_meth='Upwind_FD';
% p.shortening_meth='Upwind_TVD';

x_Speed_c=lat_advection_rate_WtoE_mpyr;%m/y
y_Speed_c=lat_advection_rate_NtoS_mpyr;%m/y

%Gradient
% I CHANGED THESE SO THERE'S NO GRADIENT
% grad_x=repmat(linspace(1,0,size(U.Z,2)),size(U.Z,1),1);
% grad_y=repmat(linspace(1,0,size(U.Z,1))',1,size(U.Z,2));

% NO GRADIENT
grad_x=repmat(ones(1,size(U.Z,2)),size(U.Z,1),1);
grad_y=repmat(ones(1,size(U.Z,1))',1,size(U.Z,2));

p.short_x = grad_x * x_Speed_c;%m/y
p.short_y = grad_y * y_Speed_c;

figure('units','normalized','outerposition',[0.1 0.1 .5 .5],'color','white');
resQv=25;
[xq, yq] =meshgrid(resQv:resQv:size(p.short_x,2),resQv:resQv:size(p.short_x,1));
xq=xq.*dx; yq=yq.*dx;
hq =quiver(xq, yq,p.short_x(resQv:resQv:size(p.short_x,1),resQv:resQv:size(p.short_x,2)),p.short_y(resQv:resQv:size(p.short_y,1),resQv:resQv:size(p.short_y,2)));
hq.Color='k';
set(gca,'ydir','reverse');
xlim([min(xq(:)) max(xq(:))])
ylim([min(yq(:)) max(yq(:))])
title('Lateral tectonic displacement');

%% Diffusion parameters
p.D = Diffusivity_m2pyr;
% p.diffScheme = 'only_sc';
p.diffScheme = 'imp_lin_sc';
% p.diffScheme = 'imp_nonlin_sc';
p.DiffToRiv=false; %If false, river elevations will only be altered by river incision
p.DiffTol=1e-4;

%% Boundary condition
p.BC_nbGhost=2;
p.BC_Type='Dirichlet';
p.BC_dir_value=100;
p.BC_dir_DistSites='';
p.BC_dir_Dist_Value=.5;

%% River incision parameters
p.Kw = Kw_value;
p.m = m_value;
p.n = n_value;
p.AreaThresh = A_cr_m2; % channel contributing area threshold [m^2]
p.NormPrecip=[]; %effective rainfall grid

if implCFL_option == 1
    
    p.implCFL = true;
    
end

if parallel_option == 1
    
    p.parallel = true;
    
end

% Changes here
K_weight = GRIDobj(H1);

K_weight.Z = ones(size(U.Z,1),size(U.Z,2)) .* K_weight_strong;

p.K_weight = K_weight;

%% Numerics river incision
% p.riverInc = 'TVD_FVM';
p.riverInc = 'implicit_FDM';
% p.riverInc = 'explicit_FDM';

%% Boundary conditions
% Default

%% Threshold slopes
p.Sc = Sc_value;
p.Sc_unit='tangent';

%% Output
p.ploteach = plot_freq;
p.saveeach = save_freq;

if Initialization_run == 1
    
    p.fileprefix = ['Set' num2str(Set,'%.0f') '_ini'];
    
elseif Initialization_run == 0
    
    p.fileprefix = ['Set' num2str(Set,'%.0f') '_Scenario' num2str(Scenario,'%.0f')];
    
end

p.FlowBC = boundary_conditions;
p.DrainDir = 'variable';

%% Initialize parameter structure
% By making p an instance of ttlemset, the user ensures parameter values
% are set in the right way
p = ttlemset(p);

%% Model run
% TTLEM can be manually interrupted by pushing the 'Stop' Bottom. The
% current model run will quit without losing the information calculated so
% far.
ttlem_out = ttlem_NM_extend_initialization(H1,U,p,time_before_weak_zone,Width_of_weak_zone_m_y_dir,...
    K_weight_strong,K_weight_weak,save_Kw_grid_option,save_Courant_grid_option,...
    max_Courant_val,early_check_Courant,time_early_check_yrs,Initialization_run,...
    enable_plotting_during_run,enable_saving_during_run,current_time_prev);
