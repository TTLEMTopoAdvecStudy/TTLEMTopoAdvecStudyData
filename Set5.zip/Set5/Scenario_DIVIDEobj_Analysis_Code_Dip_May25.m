
% Relative to the Feb28 version of the code, this one added the analysis
% of a specified percentile of ksn and Relief

clearvars
clc
close all

%%

Scenario_list_ref = [9, 10, 11, 13, 14, 15, 21, 22, 23, 25, 26, 27, 33, 34, 35];

durations_list_ref = [1E+08, 1E+08, 1E+08, 1.5E+08, 1.5E+08, 1.5E+08, ...
    1E+08, 1E+08, 1E+08, 1.5E+08, 1.5E+08, 1.5E+08, 2E+08, 2E+08, 2E+08];

Original_location = pwd;

for Loop_ref = 1:1:length(Scenario_list_ref)
    
    %% INPUT
    
    use_border_option = 0;
    
    initialization_duration_yrs_ref = 1E+08;
    
    model_duration_yrs_ref = durations_list_ref(1,Loop_ref);
    
    % Specify the set #
    Set = 5;
    
    % If this is set to 1, it will run the initialization period for the set #.
    % In other words, no weak zone is introduced during the run. If this is
    % set to 0, it will load the premade set # DEM and then introduce the weak
    % zone.
    Initialization_run = 0;
    
    % This is the scenario # within the corresponding set. If this is an
    % initialization run, then this value doesn't matter.
    Scenario = Scenario_list_ref(1,Loop_ref);
    
    % using 0.05 corresponds with the top 95th percentile of ksn and relief
    selected_exceedance_prob = 0.05;
    
    %%
    
    make_elev_range_over_t_graph = 0;
    
    make_elev_video_option = 0;
    
    enforce_clim_in_video_option = 0;
    
    min_c = 0;
    max_c = 2300;
    
    % Different analysis options
    dz_dt_Analysis = 0;
    
    DIVIDEobj_Analysis = 0;
    
    thresh_DivOrder_factor = 0.33;
    
    Eval_DrnDivAsym = 0;
    
    Analyze_Stream_Orientations = 0;
    
    Analyze_distrib_of_ksn_option = 0;
    
    Analyze_distrib_of_relief_option = 0;
    
    Analyze_distrib_of_ksn_in_strong_option = 1;
    
    Analyze_distrib_of_relief_in_strong_option = 1;
    
    Evaluate_N_S_Basins_ksn_option = 1;
    
    Evaluate_N_S_Basins_Relief_option = 1;
    
    %% READS INPUT FROM EXCEL FILE
    
    cd(Original_location)
    
    % I am not changing the boundary conditions across model runs, so I just
    % specify the conditions here. Having 'lr' makes tall walls along the
    % western and eastern boundaries.
    boundary_conditions = 'lr';
    
    % Rock-uplift rate (m/yr)
    U_rate_mpyr = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'B5');
    
    % Lateral advection is disabled in this version of the initialization!
    % Positive means from W to E, negative means from E to W
    lat_advection_rate_WtoE_mpyr = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'C5');
    
    % Positive means from N to S, negative means from S to N
    lat_advection_rate_NtoS_mpyr = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'D5');
    
    xmax_value_m = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'E5');
    
    ymax_value_m = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'F5');
    
    % Also used for dy
    dx_value_m = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'G5');
    
    timestep_yrs = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'H5');
    
    n_value = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'I5');
    m_value = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'J5');
    Kw_value = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'K5');
    
    Initial_noise_scalar_m = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'P5');
    
    plot_freq_yrs = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'R5');
    
    if Initialization_run == 1
        
        save_freq_yrs = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'S5');
        
    elseif Initialization_run ~= 1
        
        save_freq_yrs = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'S9');
        
    end
    
    % These are the number of timesteps between each intances of plotting and
    % saving
    plot_freq = ceil(plot_freq_yrs / timestep_yrs);
    save_freq = ceil(save_freq_yrs / timestep_yrs);
    
    A_cr_m2 = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'N5');
    
    Diffusivity_m2pyr = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'M5');
    
    Sc_value = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'O5');
    
    K_weight_strong = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'L5');
    
    max_Courant_val = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'V5');
    
    save_Courant_grid_option = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'W5');
    
    % If this is set to 1, the simulation will plot and save values at the time
    % specified for time_early_check_yrs. This can be important for checking
    % the Courant values so that a broken simulation doesn't wait until the
    % first plotting / saving interval to exit the while loop.
    early_check_Courant = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'T5');
    
    time_early_check_yrs = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'U5');
    
    dt_shrink_factor = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'X5');
    
    enable_plotting_during_run = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'Y5');
    
    enable_saving_during_run = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'Z5');
    
    implCFL_option = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'AA5');
    
    parallel_option = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'AB5');
    
    % INPUT SPECIFIC TO EACH SCENARIO
    if Initialization_run == 1
        
        % model_duration_yrs = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'Q5');
        model_duration_yrs = model_duration_yrs_ref;
        
        save_Kw_grid_option = 0;
        
        % This is the width of the weak zone in the y direction (i.e.,
        % north-south). The weak zone extends across the entire domain in the x
        % direction (i.e., east-west).
        Width_of_weak_zone_m_y_dir = 0;
        
        K_weight_weak = 0;
        
    elseif Initialization_run == 0
        
        % This is used to load the premade DEM
        initialization_duration_yrs = initialization_duration_yrs_ref;%xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'A8');
        
        model_duration_yrs = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'E12:E99');
        model_duration_yrs = model_duration_yrs(Scenario,1);
        
        save_Kw_grid_option = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'D12:D99');
        save_Kw_grid_option = save_Kw_grid_option(Scenario,1);
        
        % Whatever you enter for the weak zone width doesn't matter, b/c it
        % will have an unlimited width
        
        % This is the width of the weak zone in the y direction (i.e.,
        % north-south). The weak zone extends across the entire domain in the x
        % direction (i.e., east-west).
        %     Width_of_weak_zone_m_y_dir = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'C12:C99');
        %     Width_of_weak_zone_m_y_dir = Width_of_weak_zone_m_y_dir(Scenario,1);
        
        K_weight_weak = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'B12:B99');
        K_weight_weak = K_weight_weak(Scenario,1);
        
        Dip = xlsread(['TTLEM_Parameter_Space_Set' num2str(Set, '%.0f') '.xlsx'],1,'G12:G99');
        Dip = Dip(Scenario,1);
        
    end
    
    % This is the time before the weak zone enters the domain (years). Right
    % now, I have it set up so that this is either set really high so it isn't
    % used (for initialization runs) or set to zero so the weak zone enters
    % (for scenario runs).
    if Initialization_run == 1
        
        time_before_weak_zone = model_duration_yrs * 10;
        
    elseif Initialization_run == 0
        
        time_before_weak_zone = 0;
        
    end
    
    %% Make directories
    
    if exist('Output','dir') == 0
        
        %mkdir('Output');
        
    end
    
    Output_location = [pwd '/Output'];
    
    cd(Output_location)
    
    if Initialization_run == 1
        
        if exist(['Set' num2str(Set,'%.0f') '_Initialization'],'dir') == 0
            
            %mkdir(['Set' num2str(Set,'%.0f') '_Initialization']);
            
        end
        
        Set_initialization_location = [pwd ['/Set' num2str(Set,'%.0f') '_Initialization/']];
        
        p.resultsdir = Set_initialization_location;
        
    elseif Initialization_run == 0
        
        if exist(['Scenario_' num2str(Scenario,'%.0f')],'dir') == 0
            
            %mkdir(['Scenario_' num2str(Scenario,'%.0f')]);
            
        end
        
        Scenario_location = [pwd ['/Scenario_' num2str(Scenario,'%.0f') '/']];
        
        p.resultsdir = Scenario_location;
        
        Set_initialization_location = [pwd ['/Set' num2str(Set,'%.0f') '_Initialization/']];
        
    end
    
    %% Initial Surface
    % Generate random initial surface of 0 m � 50 m (or whatever
    % initial_noise_scalar_m is set to).
    
    dx=dx_value_m;%m
    Lx=xmax_value_m;
    Ly=ymax_value_m;
    x=dx:dx:Lx;
    y=dx:dx:Ly;
    
    Ymax = ymax_value_m;
    
    if Initialization_run == 1
        
        Z=zeros(numel(y),numel(x));
        Z(2:end-1,2:end-1) =rand(numel(y)-2,numel(x)-2) * Initial_noise_scalar_m;
        
        H1=GRIDobj(x,y,Z);
        %     figure('units','normalized','outerposition',[0.1 0.1 .5 .5],'color','white');
        %     imageschs(H1);
        
    elseif Initialization_run == 0
        
        cd(Set_initialization_location)
        
        load(['Set' num2str(Set,'%.0f') '_ini_t_' num2str(initialization_duration_yrs / 1e3) '_kyr.mat'],'H1');
        %     figure('units','normalized','outerposition',[0.1 0.1 .5 .5],'color','white');
        %     imageschs(H1);
        
    end
    
    %% Temporal domain
    p.TimeSpan = model_duration_yrs;
    p.TimeStep = timestep_yrs;
    
    %% Vertical uplift
    % Vertical uplift rates are considered here as a sequence of three
    % tectonic configurations.
    % Vertical uplift is inserted in TTLEM as an instance of GRIDobj
    U = GRIDobj(H1);
    
    %% FIRST uplift phase (second in users guide 3)
    % A constant uplift over 10 Myr over the entire spatial domain at 1 mm/y
    spat_u_1 = ones(size(U.Z,1), size(U.Z,2));
    spat_u_1 = spat_u_1 * U_rate_mpyr;
    spat_u_1(1,:) = 0; spat_u_1(end,:) = 0; spat_u_1(:,1) = 0; spat_u_1(:,end) = 0;
    nbOfSteps1 = p.TimeSpan / p.TimeStep;
    % U.Z(2:end-1,2:end-1,1:nbOfSteps1) = ...
    %     repmat(spat_u_1(2:end-1,2:end-1),[1,1,nbOfSteps1]);
    U.Z = spat_u_1;
    
    %Display first spatial uplift pattern
    % figure('units','normalized','outerposition',[0.1 0.1 .5 .5],'color','white');
    % imagesc(spat_u_1)
    % colorbar
    % title('Vertical uplift pattern')
    
    %% Lateral tectonic displacement
    % We insert a tectonic shortening  field operational in two directions and
    % temporally constant over the entire model simulation
    p.shortening=true;
    p.shortening_meth='Upwind_FD';
    % p.shortening_meth='Upwind_TVD';
    
    x_Speed_c=lat_advection_rate_WtoE_mpyr;%m/y
    y_Speed_c=lat_advection_rate_NtoS_mpyr;%m/y
    
    %Gradient
    % I CHANGED THESE SO THERE'S NO GRADIENT
    % grad_x=repmat(linspace(1,0,size(U.Z,2)),size(U.Z,1),1);
    % grad_y=repmat(linspace(1,0,size(U.Z,1))',1,size(U.Z,2));
    
    % NO GRADIENT
    grad_x=repmat(ones(1,size(U.Z,2)),size(U.Z,1),1);
    grad_y=repmat(ones(1,size(U.Z,1))',1,size(U.Z,2));
    
    p.short_x = grad_x * x_Speed_c;%m/y
    p.short_y = grad_y * y_Speed_c;
    
    % figure('units','normalized','outerposition',[0.1 0.1 .5 .5],'color','white');
    % resQv=25;
    % [xq, yq] =meshgrid(resQv:resQv:size(p.short_x,2),resQv:resQv:size(p.short_x,1));
    % xq=xq.*dx; yq=yq.*dx;
    % hq =quiver(xq, yq,p.short_x(resQv:resQv:size(p.short_x,1),resQv:resQv:size(p.short_x,2)),p.short_y(resQv:resQv:size(p.short_y,1),resQv:resQv:size(p.short_y,2)));
    % hq.Color='k';
    % set(gca,'ydir','reverse');
    % xlim([min(xq(:)) max(xq(:))])
    % ylim([min(yq(:)) max(yq(:))])
    % title('Lateral tectonic displacement');
    
    %% Diffusion parameters
    p.D = Diffusivity_m2pyr;
    % p.diffScheme = 'only_sc';
    p.diffScheme = 'imp_lin_sc';
    % p.diffScheme = 'imp_nonlin_sc';
    p.DiffToRiv=false; %If false, river elevations will only be altered by river incision
    p.DiffTol=1e-4;
    
    %% Boundary condition
    p.BC_nbGhost=2;
    p.BC_Type='Dirichlet';
    p.BC_dir_value=100;
    p.BC_dir_DistSites='';
    p.BC_dir_Dist_Value=0.5;
    
    %% River incision parameters
    p.Kw = Kw_value;
    p.m = m_value;
    p.n = n_value;
    p.AreaThresh = A_cr_m2; % channel contributing area threshold [m^2]
    p.NormPrecip=[]; %effective rainfall grid
    
    if implCFL_option == 1
        
        p.implCFL = true;
        
    end
    
    if parallel_option == 1
        
        p.parallel = true;
        
    end
    
    % Changes here
    K_weight = GRIDobj(H1);
    K_weight.Z = ones(size(U.Z,1),size(U.Z,2)) .* K_weight_strong;
    p.K_weight = K_weight;
    
    %% Numerics river incision
    % p.riverInc = 'TVD_FVM';
    p.riverInc = 'implicit_FDM';
    % p.riverInc = 'explicit_FDM';
    
    %% Boundary conditions
    % Default
    
    %% Threshold slopes
    p.Sc = Sc_value;
    p.Sc_unit='tangent';
    
    %% Output
    p.ploteach = plot_freq;
    p.saveeach = save_freq;
    
    if Initialization_run == 1
        
        p.fileprefix = ['Set' num2str(Set,'%.0f') '_ini'];
        
    elseif Initialization_run == 0
        
        p.fileprefix = ['Set' num2str(Set,'%.0f') '_Scenario' num2str(Scenario,'%.0f')];
        
    end
    
    p.FlowBC = boundary_conditions;
    p.DrainDir = 'variable';
    
    %% Initialize parameter structure
    % By making p an instance of ttlemset, the user ensures parameter values
    % are set in the right way
    p = ttlemset(p);
    
    %%
    
    % Navigate to the correct folder.
    resultsdir = Scenario_location;
    fileprefix = ['Set' num2str(Set, '%.0f') '_Scenario' num2str(Scenario, '%.0f')];
    
    fileprefix_initialization = ['Set' num2str(Set, '%.0f') '_ini'];
    Initialization_duration_yrs = initialization_duration_yrs;
    
    theta_ref = 0.5;
    
    xmax_m = xmax_value_m;
    ymax_m = ymax_value_m;
    
    weak_zone_width_m = 0;
    
    shortening_y_mpyr = abs(lat_advection_rate_NtoS_mpyr);
    
    %time_for_weakzone_to_leave = (ymax_m + weak_zone_width_m) / shortening_y_mpyr;
    
    AreaThresh_m2 = 1E+06;
    
    min_time = 0;
    max_time = model_duration_yrs;
    time_interval = save_freq_yrs;
    
    Relief_window_1_m = 2500;
    Relief_window_2_m = 5000;
    
    %%
    
    cd (Scenario_location)
    
    if exist('DIVIDEobj_Analysis','dir') == 0
        
        mkdir('DIVIDEobj_Analysis');
        
    end
    
    DIVIDEobj_Output_location = [Scenario_location '/DIVIDEobj_Analysis'];
    
    %% Set up
    
    if make_elev_video_option == 1
        
        scrsz = get(0,'ScreenSize');
        movieTopo = figure('OuterPosition',[0.2*scrsz(4) 0.2*scrsz(4) scrsz(4) .5*scrsz(4)],'Name','Topo','color','white');
        
        ui = 0;
        
        cd(DIVIDEobj_Output_location)
        
        % Create video file
        Vid = VideoWriter([fileprefix 'Simulation_z_over_t.avi']);
        
        open(Vid)
        
    end
    
    if make_elev_range_over_t_graph == 1
        
        first_time = 1;
        
    end
    
    time_range = min_time:time_interval:max_time;
    
    time_colors = cbrewer('div', 'Spectral', length(time_range), 'pchip');
    time_colors = flipud(time_colors);
    
    if dz_dt_Analysis == 1
        
        mean_z_m = zeros(length(time_range), 1);
        mean_z_m_N_Basins = zeros(length(time_range), 1);
        mean_z_m_S_Basins = zeros(length(time_range), 1);
        
        A_m2_N_Basins = zeros(length(time_range), 1);
        A_m2_S_Basins = zeros(length(time_range), 1);
        
        Vol_m3_entire_domain = zeros(length(time_range), 1);
        Vol_m3_N_Basins = zeros(length(time_range), 1);
        Vol_m3_S_Basins = zeros(length(time_range), 1);
        
        dz_dt_entire_domain = zeros(length(time_range), 1);
        dz_dt_N_Basins = zeros(length(time_range), 1);
        dz_dt_S_Basins = zeros(length(time_range), 1);
        
    end
    
    if Analyze_Stream_Orientations == 1
        
        drainage_density_over_time = zeros(length(time_range), 1);
        
        angle_min = 0;
        angle_interval = 1;
        angle_max = 360;
        angle_range = angle_min:angle_interval:angle_max;
        angle_range_bin_numbers = zeros(length(time_range), length(angle_range));
        
        angle_range_bin_frac_t0 = zeros(1, length(angle_range));
        angle_range_bin_frac_of_t0  = zeros(length(time_range), length(angle_range));
        
    end
    
    if Analyze_distrib_of_ksn_option == 1
        
        min_ksn_over_time = zeros(length(time_range), 1);
        max_ksn_over_time = zeros(length(time_range), 1);
        ksn_selected_excprob_over_time = zeros(length(time_range), 1);
        std_ksn_over_time = zeros(length(time_range), 1);
        
    end
    
    if Analyze_distrib_of_relief_option == 1
        
        min_relief_window1_over_time = zeros(length(time_range), 1);
        max_relief_window1_over_time = zeros(length(time_range), 1);
        relief_selected_excprob_window1_over_time = zeros(length(time_range), 1);
        std_relief_window1_over_time = zeros(length(time_range), 1);
        
        min_relief_window2_over_time = zeros(length(time_range), 1);
        max_relief_window2_over_time = zeros(length(time_range), 1);
        relief_selected_excprob_window2_over_time = zeros(length(time_range), 1);
        std_relief_window2_over_time = zeros(length(time_range), 1);
        
    end
    
    if Analyze_distrib_of_ksn_in_strong_option == 1
        
        min_ksn_in_strong_over_time = zeros(length(time_range), 1);
        max_ksn_in_strong_over_time = zeros(length(time_range), 1);
        mean_ksn_in_strong_over_time = zeros(length(time_range), 1);
        std_ksn_in_strong_over_time = zeros(length(time_range), 1);
        
    end
    
    if Evaluate_N_S_Basins_ksn_option == 1
        
        min_ksn_in_strong_N_over_time = zeros(length(time_range), 1);
        max_ksn_in_strong_N_over_time = zeros(length(time_range), 1);
        ksn_selected_excprob_in_strong_N_over_time = zeros(length(time_range), 1);
        std_ksn_in_strong_N_over_time = zeros(length(time_range), 1);
        
        min_ksn_in_strong_S_over_time = zeros(length(time_range), 1);
        max_ksn_in_strong_S_over_time = zeros(length(time_range), 1);
        ksn_selected_excprob_in_strong_S_over_time = zeros(length(time_range), 1);
        std_ksn_in_strong_S_over_time = zeros(length(time_range), 1);
        
    end
    
    if Analyze_distrib_of_relief_in_strong_option == 1
        
        min_relief_window1_in_strong_over_time = zeros(length(time_range), 1);
        max_relief_window1_in_strong_over_time = zeros(length(time_range), 1);
        mean_relief_window1_in_strong_over_time = zeros(length(time_range), 1);
        std_relief_window1_in_strong_over_time = zeros(length(time_range), 1);
        
        min_relief_window2_in_strong_over_time = zeros(length(time_range), 1);
        max_relief_window2_in_strong_over_time = zeros(length(time_range), 1);
        mean_relief_window2_in_strong_over_time = zeros(length(time_range), 1);
        std_relief_window2_in_strong_over_time = zeros(length(time_range), 1);
        
    end
    
    if Evaluate_N_S_Basins_Relief_option == 1
        
        min_relief_window1_in_strong_N_over_time = zeros(length(time_range), 1);
        max_relief_window1_in_strong_N_over_time = zeros(length(time_range), 1);
        relief_selected_excprob_window1_in_strong_N_over_time = zeros(length(time_range), 1);
        std_relief_window1_in_strong_N_over_time = zeros(length(time_range), 1);
        
        min_relief_window2_in_strong_N_over_time = zeros(length(time_range), 1);
        max_relief_window2_in_strong_N_over_time = zeros(length(time_range), 1);
        relief_selected_excprob_window2_in_strong_N_over_time = zeros(length(time_range), 1);
        std_relief_window2_in_strong_N_over_time = zeros(length(time_range), 1);
        
        min_relief_window1_in_strong_S_over_time = zeros(length(time_range), 1);
        max_relief_window1_in_strong_S_over_time = zeros(length(time_range), 1);
        relief_selected_excprob_window1_in_strong_S_over_time = zeros(length(time_range), 1);
        std_relief_window1_in_strong_S_over_time = zeros(length(time_range), 1);
        
        min_relief_window2_in_strong_S_over_time = zeros(length(time_range), 1);
        max_relief_window2_in_strong_S_over_time = zeros(length(time_range), 1);
        relief_selected_excprob_window2_in_strong_S_over_time = zeros(length(time_range), 1);
        std_relief_window2_in_strong_S_over_time = zeros(length(time_range), 1);
        
    end
    
    if DIVIDEobj_Analysis == 1
        
        mean_y_dist_km_DrnDiv_OrderAboveThresh  = zeros(length(time_range), 1);
        std_y_dist_km_DrnDiv_OrderAboveThresh  = zeros(length(time_range), 1);
        min_y_dist_km_DrnDiv_OrderAboveThresh  = zeros(length(time_range), 1);
        max_y_dist_km_DrnDiv_OrderAboveThresh  = zeros(length(time_range), 1);
        
        mean_z_m_DrnDiv_OrderAboveThresh  = zeros(length(time_range), 1);
        std_z_m_DrnDiv_OrderAboveThresh  = zeros(length(time_range), 1);
        min_z_m_DrnDiv_OrderAboveThresh  = zeros(length(time_range), 1);
        max_z_m_DrnDiv_OrderAboveThresh  = zeros(length(time_range), 1);
        
        mean_Relief_m_DrnDiv_OrderAboveThresh  = zeros(length(time_range), 1);
        std_Relief_m_DrnDiv_OrderAboveThresh  = zeros(length(time_range), 1);
        min_Relief_m_DrnDiv_OrderAboveThresh  = zeros(length(time_range), 1);
        max_Relief_m_DrnDiv_OrderAboveThresh  = zeros(length(time_range), 1);
        
        max_DivOrd  = zeros(length(time_range), 1);
        
        %     weak_zone_northern_y_dist_km_over_t  = zeros(length(time_range), 1);
        %     weak_zone_southern_y_dist_km_over_t  = zeros(length(time_range), 1);
        
        if Eval_DrnDivAsym == 1
            
            mean_DivAsym_rho_Order4_DrnDiv  = zeros(length(time_range), 1);
            std_DivAsym_rho_Order4_DrnDiv  = zeros(length(time_range), 1);
            min_DivAsym_rho_Order4_DrnDiv  = zeros(length(time_range), 1);
            max_DivAsym_rho_Order4_DrnDiv  = zeros(length(time_range), 1);
            
            mean_DivAsym_u_Order4_DrnDiv = zeros(length(time_range), 1);
            std_DivAsym_u_Order4_DrnDiv = zeros(length(time_range), 1);
            min_DivAsym_u_Order4_DrnDiv = zeros(length(time_range), 1);
            max_DivAsym_u_Order4_DrnDiv = zeros(length(time_range), 1);
            
            mean_DivAsym_v_Order4_DrnDiv = zeros(length(time_range), 1);
            std_DivAsym_v_Order4_DrnDiv = zeros(length(time_range), 1);
            min_DivAsym_v_Order4_DrnDiv = zeros(length(time_range), 1);
            max_DivAsym_v_Order4_DrnDiv = zeros(length(time_range), 1);
            
        end
        
    end
    
    %%
    
    t_ref = 0;
    
    for t = min_time:time_interval:max_time
        
        t_ref = t_ref + 1;
        
        if t == min_time
            
            cd(Set_initialization_location)
            
            load([fileprefix_initialization '_t_' num2str(Initialization_duration_yrs / 1000, '%.0f') '_kyr.mat'],'H1');
            
            % These don't change with time, so you only have to get them once
            [x,y] = getcoordinates(H1,'GRIDobj');
            
            BORDER = GRIDobj(H1,'logical');
            
            if use_border_option == 1
                
                % Make "walls" along the left and right borders, same as in the
                % simulation
                BORDER.Z(:,1) = 1;
                BORDER.Z(:,end) = 1;
                BORDER.Z = BORDER.Z .* 10000;
                
            end
            
            cd(Scenario_location)
            
        elseif t ~= 0
            
            load([fileprefix '_t_' num2str(round(t / 1e3)) '_kyr.mat'],...
                'H1','Kw_grid');
            
        end
        
        if DIVIDEobj_Analysis == 1 || Analyze_Stream_Orientations == 1 ...
                || make_elev_video_option == 1 || dz_dt_Analysis == 1 ...
                || Analyze_distrib_of_ksn_option == 1 || Analyze_distrib_of_ksn_in_strong_option == 1
            
            FlwDir = FLOWobj(H1 + BORDER,'mex',true,'preprocess','c');
            
            
            % Don't need this for dz_dt_Analysis
            if DIVIDEobj_Analysis == 1 || Analyze_Stream_Orientations == 1 ...
                    || make_elev_video_option == 1 ...
                    || Analyze_distrib_of_ksn_option == 1 || Analyze_distrib_of_ksn_in_strong_option == 1
                
                FlwAcc  = flowacc(FlwDir);
                
                % Gets rid of the flow accumulation along the boundaries
                FlwAcc.Z(1,:) = 0;
                FlwAcc.Z(end,:) = 0;
                FlwAcc.Z(:,1) = 0;
                FlwAcc.Z(:,end) = 0;
                
                Stream = STREAMobj(FlwDir, FlwAcc >= (AreaThresh_m2 / (H1.cellsize ^ 2)));
                
            end
            
        end
        
        %%
        
        if dz_dt_Analysis == 1
            
            mean_z_m(t_ref,1) = mean(H1.Z, 'all');
            
            N_Basins = drainagebasins(FlwDir, x.Z(1,:), y.Z(1,:));
            N_Basins.Z(N_Basins.Z ~= 0) = 1;
            
            % figure(4)
            %
            % imageschs(H1, N_Basins)
            
            S_Basins = drainagebasins(FlwDir, x.Z(1,:), y.Z(end,:));
            S_Basins.Z(S_Basins.Z ~= 0) = 1;
            
            % figure(5)
            %
            % imageschs(H1, S_Basins)
            
            mean_z_m_N_Basins(t_ref,1) = mean(H1.Z(N_Basins.Z == 1), 'all');
            A_m2_N_Basins(t_ref,1) = length(N_Basins.Z(N_Basins.Z == 1)) ...
                .* (H1.cellsize .^ 2);
            Vol_m3_N_Basins(t_ref,1) = A_m2_N_Basins(t_ref,1) * mean_z_m_N_Basins(t_ref,1);
            
            mean_z_m_S_Basins(t_ref,1) = mean(H1.Z(S_Basins.Z == 1), 'all');
            A_m2_S_Basins(t_ref,1) = length(S_Basins.Z(S_Basins.Z == 1)) ...
                .* (H1.cellsize .^ 2);
            Vol_m3_S_Basins(t_ref,1) = A_m2_S_Basins(t_ref,1) * mean_z_m_S_Basins(t_ref,1);
            
            if t_ref ~= 1
                
                dz_dt_entire_domain(t_ref, 1) = (mean_z_m(t_ref,1) - mean_z_m(t_ref-1,1)) / time_interval;
                dz_dt_N_Basins(t_ref, 1) = (mean_z_m_N_Basins(t_ref,1) - mean_z_m_N_Basins(t_ref-1,1)) / time_interval;
                dz_dt_S_Basins(t_ref, 1) = (mean_z_m_S_Basins(t_ref,1) - mean_z_m_S_Basins(t_ref-1,1)) / time_interval;
                
            end
            
        end
        
        %%
        
        if Evaluate_N_S_Basins_ksn_option == 1 || Evaluate_N_S_Basins_Relief_option == 1
            
            % After getting the basins draining to the N and S boundaries,
            % I overwrite the basin numbers to all be 1 (I don't deal with
            % individual draianges, I just want all basins drianaing N or S).
            N_Basins = drainagebasins(FlwDir, x.Z(1,:), y.Z(1,:));
            N_Basins.Z(N_Basins.Z ~= 0) = 1;
            
            S_Basins = drainagebasins(FlwDir, x.Z(1,:), y.Z(end,:));
            S_Basins.Z(S_Basins.Z ~= 0) = 1;
            
        end
        
        %%
        
        if Analyze_distrib_of_ksn_option == 1 || Analyze_distrib_of_ksn_in_strong_option == 1
            
            if Analyze_distrib_of_ksn_option == 1
                
                Grad = gradient8(H1, 'per');
                
                ksn_grid = (Grad ./ 100) ./ ((FlwAcc .* (FlwAcc.cellsize ^ 2)) .^ (-theta_ref));
                ksn_grid.Z(FlwAcc.Z <= (AreaThresh_m2 / (H1.cellsize ^ 2))) = NaN;
                ksn_grid.Z(:,1) = NaN;
                ksn_grid.Z(:,2) = NaN;
                ksn_grid.Z(:,end) = NaN;
                ksn_grid.Z(:,end-1) = NaN;
                ksn_grid.Z(1,:) = NaN;
                ksn_grid.Z(2,:) = NaN;
                ksn_grid.Z(end,:) = NaN;
                ksn_grid.Z(end-1,:) = NaN;
                
                min_ksn_over_time(t_ref,1) = min(min(ksn_grid.Z));
                max_ksn_over_time(t_ref,1) = max(max(ksn_grid.Z));
                ksn_selected_excprob_over_time(t_ref,1) = mean(ksn_grid.Z, 'all', 'omitnan');
                std_ksn_over_time(t_ref,1) = std(ksn_grid.Z, 0, 'all', 'omitnan');
                
            end
            
            if Analyze_distrib_of_ksn_in_strong_option == 1
                
                if Analyze_distrib_of_ksn_option ~= 1
                    
                    Grad = gradient8(H1, 'per');
                    
                    ksn_grid = (Grad ./ 100) ./ ((FlwAcc .* (FlwAcc.cellsize ^ 2)) .^ (-theta_ref));
                    ksn_grid.Z(FlwAcc.Z <= (AreaThresh_m2 / (H1.cellsize ^ 2))) = NaN;
                    ksn_grid.Z(:,1) = NaN;
                    ksn_grid.Z(:,2) = NaN;
                    ksn_grid.Z(:,end) = NaN;
                    ksn_grid.Z(:,end-1) = NaN;
                    ksn_grid.Z(1,:) = NaN;
                    ksn_grid.Z(2,:) = NaN;
                    ksn_grid.Z(end,:) = NaN;
                    ksn_grid.Z(end-1,:) = NaN;
                    
                end
                
                if t_ref ~= 1
                    
                    ksn_grid.Z(Kw_grid.Z == (Kw_value * K_weight_weak)) = NaN;
                    
                end
                
                min_ksn_in_strong_over_time(t_ref,1) = min(min(ksn_grid.Z));
                max_ksn_in_strong_over_time(t_ref,1) = max(max(ksn_grid.Z));
                mean_ksn_in_strong_over_time(t_ref,1) = mean(ksn_grid.Z, 'all', 'omitnan');
                std_ksn_in_strong_over_time(t_ref,1) = std(ksn_grid.Z, 0, 'all', 'omitnan');
                
                if Evaluate_N_S_Basins_ksn_option == 1
                    
                    ksn_temp = ksn_grid.Z(N_Basins.Z == 1);
                    ksn_temp = ksn_temp(~isnan(ksn_temp));
                    
                    exceedance_prob = (1:1:length(ksn_temp)) ./ (length(ksn_temp) + 1);
                    
                    prox_to_selected_exceedance = abs(exceedance_prob - selected_exceedance_prob) ./ selected_exceedance_prob;
                    
                    sorted_ksn = sort(ksn_temp, 'descend');
                    
                    min_ksn_in_strong_N_over_time(t_ref,1) = min(min(ksn_grid.Z(N_Basins.Z == 1)));
                    max_ksn_in_strong_N_over_time(t_ref,1) = max(max(ksn_grid.Z(N_Basins.Z == 1)));
                    
                    if isempty(min(sorted_ksn(prox_to_selected_exceedance == min(prox_to_selected_exceedance)))) ~= 1
                        
                        ksn_selected_excprob_in_strong_N_over_time(t_ref,1) = min(sorted_ksn(prox_to_selected_exceedance == min(prox_to_selected_exceedance)));
                        
                    elseif isempty(min(sorted_ksn(prox_to_selected_exceedance == min(prox_to_selected_exceedance)))) == 1
                        
                        ksn_selected_excprob_in_strong_N_over_time(t_ref,1) = NaN;
                        
                    end
                    
                    std_ksn_in_strong_N_over_time(t_ref,1) = std(ksn_grid.Z(N_Basins.Z == 1), 0, 'all', 'omitnan');
                    
                    ksn_temp = ksn_grid.Z(S_Basins.Z == 1);
                    ksn_temp = ksn_temp(~isnan(ksn_temp));
                    
                    exceedance_prob = (1:1:length(ksn_temp)) ./ (length(ksn_temp) + 1);
                    
                    prox_to_selected_exceedance = abs(exceedance_prob - selected_exceedance_prob) ./ selected_exceedance_prob;
                    
                    sorted_ksn = sort(ksn_temp, 'descend');
                    
                    min_ksn_in_strong_S_over_time(t_ref,1) = min(min(ksn_grid.Z(S_Basins.Z == 1)));
                    max_ksn_in_strong_S_over_time(t_ref,1) = max(max(ksn_grid.Z(S_Basins.Z == 1)));
                    
                    if isempty(min(sorted_ksn(prox_to_selected_exceedance == min(prox_to_selected_exceedance)))) ~= 1
                        
                        ksn_selected_excprob_in_strong_S_over_time(t_ref,1) = min(sorted_ksn(prox_to_selected_exceedance == min(prox_to_selected_exceedance)));
                        
                    elseif isempty(min(sorted_ksn(prox_to_selected_exceedance == min(prox_to_selected_exceedance)))) == 1
                        
                        ksn_selected_excprob_in_strong_S_over_time(t_ref,1) = NaN;
                        
                    end
                    
                    std_ksn_in_strong_S_over_time(t_ref,1) = std(ksn_grid.Z(S_Basins.Z == 1), 0, 'all', 'omitnan');
                    
                end
                
            end
            
        end
        
        %%
        
        if Analyze_distrib_of_relief_option == 1 || Analyze_distrib_of_relief_in_strong_option == 1
            
            if Analyze_distrib_of_relief_option == 1
                
                Relief_m = localtopography(H1, Relief_window_1_m);
                
                min_relief_window1_over_time(t_ref,1) = min(min(Relief_m.Z));
                max_relief_window1_over_time(t_ref,1) = max(max(Relief_m.Z));
                relief_selected_excprob_window1_over_time(t_ref,1) = mean(Relief_m.Z, 'all');
                std_relief_window1_over_time(t_ref,1) = std(Relief_m.Z, 0, 'all', 'omitnan');
                
            end
            
            if Analyze_distrib_of_relief_in_strong_option == 1
                
                if Analyze_distrib_of_relief_option ~= 1
                    
                    Relief_m = localtopography(H1, Relief_window_1_m);
                    
                end
                
                if t_ref ~= 1
                    
                    Relief_m.Z(Kw_grid.Z == (Kw_value * K_weight_weak)) = NaN;
                    
                end
                
                min_relief_window1_in_strong_over_time(t_ref,1) = min(min(Relief_m.Z));
                max_relief_window1_in_strong_over_time(t_ref,1) = max(max(Relief_m.Z));
                mean_relief_window1_in_strong_over_time(t_ref,1) = mean(Relief_m.Z, 'all', 'omitnan');
                std_relief_window1_in_strong_over_time(t_ref,1) = std(Relief_m.Z, 0, 'all', 'omitnan');
                
                if Evaluate_N_S_Basins_Relief_option == 1
                    
                    Relief_temp = Relief_m.Z(N_Basins.Z == 1);
                    Relief_temp = Relief_temp(~isnan(Relief_temp));
                    
                    exceedance_prob = (1:1:length(Relief_temp)) ./ (length(Relief_temp) + 1);
                    
                    prox_to_selected_exceedance = abs(exceedance_prob - selected_exceedance_prob) ./ selected_exceedance_prob;
                    
                    sorted_Relief = sort(Relief_temp, 'descend');
                    
                    min_relief_window1_in_strong_N_over_time(t_ref,1) = min(min(Relief_m.Z(N_Basins.Z == 1)));
                    max_relief_window1_in_strong_N_over_time(t_ref,1) = max(max(Relief_m.Z(N_Basins.Z == 1)));
                    
                    if isempty(min(sorted_Relief(prox_to_selected_exceedance == min(prox_to_selected_exceedance)))) ~= 1
                        
                        relief_selected_excprob_window1_in_strong_N_over_time(t_ref,1) = min(sorted_Relief(prox_to_selected_exceedance == min(prox_to_selected_exceedance)));
                        
                    elseif isempty(min(sorted_Relief(prox_to_selected_exceedance == min(prox_to_selected_exceedance)))) == 1
                        
                        relief_selected_excprob_window1_in_strong_N_over_time(t_ref,1) = NaN;
                        
                    end
                    
                    std_relief_window1_in_strong_N_over_time(t_ref,1) = std(Relief_m.Z(N_Basins.Z == 1), 0, 'all', 'omitnan');
                    
                    Relief_temp = Relief_m.Z(S_Basins.Z == 1);
                    Relief_temp = Relief_temp(~isnan(Relief_temp));
                    
                    exceedance_prob = (1:1:length(Relief_temp)) ./ (length(Relief_temp) + 1);
                    
                    prox_to_selected_exceedance = abs(exceedance_prob - selected_exceedance_prob) ./ selected_exceedance_prob;
                    
                    sorted_Relief = sort(Relief_temp, 'descend');
                    
                    min_relief_window1_in_strong_S_over_time(t_ref,1) = min(min(Relief_m.Z(S_Basins.Z == 1)));
                    max_relief_window1_in_strong_S_over_time(t_ref,1) = max(max(Relief_m.Z(S_Basins.Z == 1)));
                    
                    if isempty(min(sorted_Relief(prox_to_selected_exceedance == min(prox_to_selected_exceedance)))) ~= 1
                        
                        relief_selected_excprob_window1_in_strong_S_over_time(t_ref,1) = min(sorted_Relief(prox_to_selected_exceedance == min(prox_to_selected_exceedance)));
                        
                    elseif isempty(min(sorted_Relief(prox_to_selected_exceedance == min(prox_to_selected_exceedance)))) == 1
                        
                        relief_selected_excprob_window1_in_strong_S_over_time(t_ref,1) = NaN;
                        
                    end
                    
                    std_relief_window1_in_strong_S_over_time(t_ref,1) = std(Relief_m.Z(S_Basins.Z == 1), 0, 'all', 'omitnan');
                    
                end
                
            end
            
            if Analyze_distrib_of_relief_option == 1
                
                Relief_m = localtopography(H1, Relief_window_2_m);
                
                min_relief_window2_over_time(t_ref,1) = min(min(Relief_m.Z));
                max_relief_window2_over_time(t_ref,1) = max(max(Relief_m.Z));
                relief_selected_excprob_window2_over_time(t_ref,1) = mean(Relief_m.Z, 'all', 'omitnan');
                std_relief_window2_over_time(t_ref,1) = std(Relief_m.Z, 0, 'all', 'omitnan');
                
            end
            
            if Analyze_distrib_of_relief_in_strong_option == 1
                
                if Analyze_distrib_of_relief_option ~= 1
                    
                    Relief_m = localtopography(H1, Relief_window_2_m);
                    
                end
                
                if t_ref ~= 1
                    
                    Relief_m.Z(Kw_grid.Z == (Kw_value * K_weight_weak)) = NaN;
                    
                end
                
                min_relief_window2_in_strong_over_time(t_ref,1) = min(min(Relief_m.Z));
                max_relief_window2_in_strong_over_time(t_ref,1) = max(max(Relief_m.Z));
                mean_relief_window2_in_strong_over_time(t_ref,1) = mean(Relief_m.Z, 'all', 'omitnan');
                std_relief_window2_in_strong_over_time(t_ref,1) = std(Relief_m.Z, 0, 'all', 'omitnan');
                
                if Evaluate_N_S_Basins_Relief_option == 1
                    
                    Relief_temp = Relief_m.Z(N_Basins.Z == 1);
                    Relief_temp = Relief_temp(~isnan(Relief_temp));
                    
                    exceedance_prob = (1:1:length(Relief_temp)) ./ (length(Relief_temp) + 1);
                    
                    prox_to_selected_exceedance = abs(exceedance_prob - selected_exceedance_prob) ./ selected_exceedance_prob;
                    
                    sorted_Relief = sort(Relief_temp, 'descend');
                    
                    min_relief_window2_in_strong_N_over_time(t_ref,1) = min(min(Relief_m.Z(N_Basins.Z == 1)));
                    max_relief_window2_in_strong_N_over_time(t_ref,1) = max(max(Relief_m.Z(N_Basins.Z == 1)));
                    
                    if isempty(min(sorted_Relief(prox_to_selected_exceedance == min(prox_to_selected_exceedance)))) ~= 1
                        
                        relief_selected_excprob_window2_in_strong_N_over_time(t_ref,1) = min(sorted_Relief(prox_to_selected_exceedance == min(prox_to_selected_exceedance)));
                        
                    elseif isempty(min(sorted_Relief(prox_to_selected_exceedance == min(prox_to_selected_exceedance)))) == 1
                        
                        relief_selected_excprob_window2_in_strong_N_over_time(t_ref,1) = NaN;
                        
                    end
                    
                    std_relief_window2_in_strong_N_over_time(t_ref,1) = std(Relief_m.Z(N_Basins.Z == 1), 0, 'all', 'omitnan');
                    
                    Relief_temp = Relief_m.Z(S_Basins.Z == 1);
                    Relief_temp = Relief_temp(~isnan(Relief_temp));
                    
                    exceedance_prob = (1:1:length(Relief_temp)) ./ (length(Relief_temp) + 1);
                    
                    prox_to_selected_exceedance = abs(exceedance_prob - selected_exceedance_prob) ./ selected_exceedance_prob;
                    
                    sorted_Relief = sort(Relief_temp, 'descend');
                    
                    min_relief_window2_in_strong_S_over_time(t_ref,1) = min(min(Relief_m.Z(S_Basins.Z == 1)));
                    max_relief_window2_in_strong_S_over_time(t_ref,1) = max(max(Relief_m.Z(S_Basins.Z == 1)));
                    
                    if isempty(min(sorted_Relief(prox_to_selected_exceedance == min(prox_to_selected_exceedance)))) ~= 1
                        
                        relief_selected_excprob_window2_in_strong_S_over_time(t_ref,1) = min(sorted_Relief(prox_to_selected_exceedance == min(prox_to_selected_exceedance)));
                        
                    elseif isempty(min(sorted_Relief(prox_to_selected_exceedance == min(prox_to_selected_exceedance)))) == 1
                        
                        relief_selected_excprob_window2_in_strong_S_over_time(t_ref,1) = NaN;
                        
                    end
                    
                    std_relief_window2_in_strong_S_over_time(t_ref,1) = std(Relief_m.Z(S_Basins.Z == 1), 0, 'all', 'omitnan');
                    
                end
                
            end
            
        end
        
        %% Analyze Divide objects
        
        if DIVIDEobj_Analysis == 1
            
            DrnDiv = DIVIDEobj(FlwDir, Stream);
            DrnDiv = cleanedges(DrnDiv,FlwDir);
            
            DrnDiv = sort(DrnDiv);
            
            DrnDiv = divorder(DrnDiv,'topo');
            
            thresh_DivOrder = (max(DrnDiv.order) * thresh_DivOrder_factor);
            
            % I only used this to to check where the selected divide segments
            % were
            %         DrnDiv_plot = DrnDiv;
            %         DrnDiv_plot.order(DrnDiv_plot.order < thresh_DivOrder) = NaN;
            %
            %         figure(40)
            %
            %         imageschs(H1, H1)
            %         hold on
            %         plot(DrnDiv_plot)
            %         hold on
            
            if Eval_DrnDivAsym == 1
                
                Zdist2Stream = vertdistance2stream(FlwDir,Stream,H1);
                [MS] = asymmetry(DrnDiv,Zdist2Stream);
                
                DivAsym_dist = [MS.dist];
                DivAsym_rho = [MS.rho];
                DivAsym_u = [MS.u];
                DivAsym_v = [MS.v];
                DivAsym_order = [MS.order];
                
                %         figure(50)
                %
                %         plot(DivAsym_dist, DivAsym_rho, 'color', time_colors(t_ref,:), ...
                %             'linestyle', 'none', 'marker', 'o', 'linewidth', 1.5)
                %         hold on
                
                % Get the asymmetry index (Divide Assymetry Index) values along the
                % drainage divides with orders above the threshold
                mean_DivAsym_rho_Order4_DrnDiv(t_ref,1) = mean(DivAsym_rho(DivAsym_order >= thresh_DivOrder & isnan(DivAsym_rho) ~= 1));
                std_DivAsym_rho_Order4_DrnDiv(t_ref,1) = std(DivAsym_rho(DivAsym_order >= thresh_DivOrder & isnan(DivAsym_rho) ~= 1));
                min_DivAsym_rho_Order4_DrnDiv(t_ref,1) = min(DivAsym_rho(DivAsym_order >= thresh_DivOrder & isnan(DivAsym_rho) ~= 1));
                max_DivAsym_rho_Order4_DrnDiv(t_ref,1) = max(DivAsym_rho(DivAsym_order >= thresh_DivOrder & isnan(DivAsym_rho) ~= 1));
                
                mean_DivAsym_u_Order4_DrnDiv(t_ref,1) = mean(DivAsym_u(DivAsym_order >= thresh_DivOrder& isnan(DivAsym_u) ~= 1));
                std_DivAsym_u_Order4_DrnDiv(t_ref,1) = std(DivAsym_u(DivAsym_order >= thresh_DivOrder & isnan(DivAsym_u) ~= 1));
                min_DivAsym_u_Order4_DrnDiv(t_ref,1) = min(DivAsym_u(DivAsym_order >= thresh_DivOrder & isnan(DivAsym_u) ~= 1));
                max_DivAsym_u_Order4_DrnDiv(t_ref,1) = max(DivAsym_u(DivAsym_order >= thresh_DivOrder & isnan(DivAsym_u) ~= 1));
                
                mean_DivAsym_v_Order4_DrnDiv(t_ref,1) = mean(DivAsym_u(DivAsym_order >= thresh_DivOrder & isnan(DivAsym_v) ~= 1));
                std_DivAsym_v_Order4_DrnDiv(t_ref,1) = std(DivAsym_u(DivAsym_order >= thresh_DivOrder & isnan(DivAsym_v) ~= 1));
                min_DivAsym_v_Order4_DrnDiv(t_ref,1) = min(DivAsym_u(DivAsym_order >= thresh_DivOrder & isnan(DivAsym_v) ~= 1));
                max_DivAsym_v_Order4_DrnDiv(t_ref,1) = max(DivAsym_u(DivAsym_order >= thresh_DivOrder & isnan(DivAsym_v) ~= 1));
                
            end
            
            max_DivOrd(t_ref,1) = max(DrnDiv.order);
            
            % Get the y values along drainage divides with orders above the
            % threshold
            [r] = getvalue(DrnDiv, y);
            
            mean_y_dist_km_DrnDiv_OrderAboveThresh(t_ref,1) = mean(r(DrnDiv.order >= thresh_DivOrder & isnan(DrnDiv.order) ~= 1 & isnan(r) ~= 1)) / 1000;
            std_y_dist_km_DrnDiv_OrderAboveThresh(t_ref,1) = std(r(DrnDiv.order >= thresh_DivOrder & isnan(DrnDiv.order) ~= 1 & isnan(r) ~= 1)) / 1000;
            min_y_dist_km_DrnDiv_OrderAboveThresh(t_ref,1) = min(r(DrnDiv.order >= thresh_DivOrder & isnan(DrnDiv.order) ~= 1 & isnan(r) ~= 1)) / 1000;
            max_y_dist_km_DrnDiv_OrderAboveThresh(t_ref,1) = max(r(DrnDiv.order >= thresh_DivOrder & isnan(DrnDiv.order) ~= 1 & isnan(r) ~= 1)) / 1000;
            
            % Get the z values along drainage divides with orders above the
            % threshold
            [r] = getvalue(DrnDiv, H1);
            
            mean_z_m_DrnDiv_OrderAboveThresh(t_ref,1) = mean(r(DrnDiv.order >= thresh_DivOrder & isnan(DrnDiv.order) ~= 1 & isnan(r) ~= 1));
            std_z_m_DrnDiv_OrderAboveThresh(t_ref,1) = std(r(DrnDiv.order >= thresh_DivOrder & isnan(DrnDiv.order) ~= 1 & isnan(r) ~= 1));
            min_z_m_DrnDiv_OrderAboveThresh(t_ref,1) = min(r(DrnDiv.order >= thresh_DivOrder & isnan(DrnDiv.order) ~= 1 & isnan(r) ~= 1));
            max_z_m_DrnDiv_OrderAboveThresh(t_ref,1) = max(r(DrnDiv.order >= thresh_DivOrder & isnan(DrnDiv.order) ~= 1 & isnan(r) ~= 1));
            
            % Right now, I'm only using Relief window_1 for this
            Relief_m = localtopography(H1, Relief_window_1_m);
            
            % Get the Relief values along drainage divides with orders above the
            % threshold
            [r] = getvalue(DrnDiv, Relief_m);
            
            mean_Relief_m_DrnDiv_OrderAboveThresh(t_ref,1) = mean(r(DrnDiv.order >= thresh_DivOrder & isnan(DrnDiv.order) ~= 1 & isnan(r) ~= 1));
            std_Relief_m_DrnDiv_OrderAboveThresh(t_ref,1) = std(r(DrnDiv.order >= thresh_DivOrder & isnan(DrnDiv.order) ~= 1 & isnan(r) ~= 1));
            min_Relief_m_DrnDiv_OrderAboveThresh(t_ref,1) = min(r(DrnDiv.order >= thresh_DivOrder & isnan(DrnDiv.order) ~= 1 & isnan(r) ~= 1));
            max_Relief_m_DrnDiv_OrderAboveThresh(t_ref,1) = max(r(DrnDiv.order >= thresh_DivOrder & isnan(DrnDiv.order) ~= 1 & isnan(r) ~= 1));
            
            %         if t ~= 0 && t < time_for_weakzone_to_leave
            %
            %             weak_zone_northern_y_dist_km_over_t(t_ref,1) = y.Z(weak_zone_northern_row,1) / 1000;
            %             weak_zone_southern_y_dist_km_over_t(t_ref,1) = y.Z(weak_zone_southern_row,1) / 1000;
            %
            %         end
            
        end
        
        %% Elevations video
        
        if make_elev_video_option == 1
            
            ui = ui + 1;
            figure(movieTopo)
            
            if enforce_clim_in_video_option == 1
                
                imageschs(H1,H1,'caxis', [min_c max_c], 'colormap', 'gray', ...
                    'ticksToKm', true, 'colorBarLabel', '\bfm');
                hold on
                
            elseif enforce_clim_in_video_option ~= 1
                
                imageschs(H1,H1, 'colormap', 'gray', ...
                    'ticksToKm', true, 'colorBarLabel', '\bfm');
                hold on
                
            end
            
            Stream.x=Stream.x*1e-3;
            Stream.y=Stream.y*1e-3;
            plot(Stream,'b','linewidth',1);
            hold off
            xlabel('\bfX Coordinate, km')
            ylabel('\bfY Coordinate, km')
            title([num2str((t*1e-6), '%.1f') ' Myr']);
            
            set(gcf, 'renderer', 'Painters')
            
            movie1(ui)=getframe(gcf); %#ok<SAGROW>
            writeVideo(Vid,movie1(ui))
            
        end
        
        if make_elev_range_over_t_graph == 1
            
            figure(2)
            
            if first_time == 1
                
                h_min = plot(t / 1E+06, min(min(H1.Z)), 'color', 'b', 'marker', 's', ...
                    'linestyle', 'none', 'linewidth', 1);
                hold on
                
                h_max = plot(t / 1E+06, max(max(H1.Z)), 'color', 'r', 'marker', '^', ...
                    'linestyle', 'none', 'linewidth', 1);
                hold on
                
                h_mean = plot(t / 1E+06, mean(H1.Z, 'all'), 'color', 'k', 'marker', 'o', ...
                    'linestyle', 'none', 'linewidth', 1);
                hold on
                
                first_time = 0;
                
            elseif first_time ~= 1
                
                plot(t / 1E+06, min(min(H1.Z)), 'color', 'b', 'marker', 's', ...
                    'linestyle', 'none', 'linewidth', 1.5)
                hold on
                
                plot(t / 1E+06, max(max(H1.Z)), 'color', 'r', 'marker', '^', ...
                    'linestyle', 'none', 'linewidth', 1)
                hold on
                
                plot(t / 1E+06, mean(H1.Z, 'all'), 'color', 'k', 'marker', 'o', ...
                    'linestyle', 'none', 'linewidth', 1)
                hold on
                
            end
            
        end
        
        if Analyze_Stream_Orientations == 1
            
            % 0 degrees is flow to the north, degrees are measured clockwise
            % from north (e.g., 90 degrees represents flow to the eastward, 180
            % degrees represents flow to the south).
            Orientation = orientation(Stream, 'unit', 'degrees');
            
            for i = 1:1:length(Orientation)
                
                for j = 1:1:length(angle_range)
                    
                    if j == 1
                        
                        if Orientation(i,1) < angle_range(1,j+1)
                            
                            angle_range_bin_numbers(t_ref,j) = angle_range_bin_numbers(t_ref,j) + 1;
                            
                        end
                        
                    else
                        
                        if Orientation(i,1) > angle_range(1,j-1) & Orientation(i,1) <= angle_range(1,j)
                            
                            angle_range_bin_numbers(t_ref,j) = angle_range_bin_numbers(t_ref,j) + 1;
                            
                        end
                        
                    end
                    
                end
                
            end
            
            for j = 1:1:length(angle_range)
                
                if t == 0
                    
                    angle_range_bin_frac_t0(1,j) = angle_range_bin_numbers(t_ref,j) ...
                        ./ (sum(angle_range_bin_numbers(t_ref,:)));
                    
                elseif t ~= 0
                    
                    angle_range_bin_frac_of_t0(t_ref,j) = (angle_range_bin_numbers(t_ref,j) ...
                        ./ (sum(angle_range_bin_numbers(t_ref,:)))) ...
                        / angle_range_bin_frac_t0(1,j);
                    
                end
                
            end
            
            if t ~= 0
                
                figure(3)
                
                plot(angle_range, angle_range_bin_frac_of_t0(t_ref,:), ...
                    'linewidth', 1.5, 'color', time_colors(t_ref,:))
                hold on
                
                %             plot(angle_range, angle_range_bin_numbers(t_ref,:) ...
                %                 ./ (sum(angle_range_bin_numbers(t_ref,:))), ...
                %                 'linewidth', 1.5, 'color', time_colors(t_ref,:))
                %             hold on
                
            end
            
        end
        
    end
    
    cd(DIVIDEobj_Output_location)
    
    %%
    
    % if DIVIDEobj_Analysis == 1
    %
    %     dmin_y_dist_km_dt_Order4_DrnDiv = zeros(length(time_range), 1);
    %     dmax_y_dist_km_dt_Order4_DrnDiv = zeros(length(time_range), 1);
    %     dmean_y_dist_km_dt_Order4_DrnDiv = zeros(length(time_range), 1);
    %     dstd_y_dist_km_dt_Order4_DrnDiv = zeros(length(time_range), 1);
    %
    %     for j = 2:1:length(time_range)
    %
    %         dmin_y_dist_km_dt_Order4_DrnDiv(j,1) = (min_y_dist_km_DrnDiv_OrderAboveThresh(j,1) - ...
    %             min_y_dist_km_DrnDiv_OrderAboveThresh(j-1,1)) / time_interval;
    %
    %         dmax_y_dist_km_dt_Order4_DrnDiv(j,1) = (max_y_dist_km_DrnDiv_OrderAboveThresh(j,1) - ...
    %             max_y_dist_km_DrnDiv_OrderAboveThresh(j-1,1)) / time_interval;
    %
    %         dmean_y_dist_km_dt_Order4_DrnDiv(j,1) = (mean_y_dist_km_DrnDiv_OrderAboveThresh(j,1) - ...
    %             mean_y_dist_km_DrnDiv_OrderAboveThresh(j-1,1)) / time_interval;
    %
    %         dstd_y_dist_km_dt_Order4_DrnDiv(j,1) = (mean_y_dist_km_DrnDiv_OrderAboveThresh(j,1) - ...
    %             mean_y_dist_km_DrnDiv_OrderAboveThresh(j-1,1)) / time_interval;
    %
    %     end
    %
    % end
    
    %%
    
    if dz_dt_Analysis == 1
        
        Vol_m3_entire_domain = mean_z_m .* (xmax_m * ymax_m);
        
        figure(50)
        
        h_entire = plot(time_range(1,2:end) ./ 1E+06, dz_dt_entire_domain(2:end,1) .* 1000, ...
            'marker', 'o', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        hold on
        
        h_N = plot(time_range(1,2:end) ./ 1E+06, dz_dt_N_Basins(2:end,1) .* 1000, ...
            'marker', 'o', 'linewidth', 1, 'color', 'b', 'markersize', 5);
        hold on
        
        h_S = plot(time_range(1,2:end) ./ 1E+06, dz_dt_S_Basins(2:end,1) .* 1000, ...
            'marker', 'o', 'linewidth', 1, 'color', 'r', 'markersize', 5);
        hold on
        
        ylim_ref = ylim;
        
        %         h_weak_zone = plot([time_for_weakzone_to_leave, time_for_weakzone_to_leave] ./ 1E+06, [ylim_ref(1,1), ylim_ref(1,2)], ...
        %             'marker', 'none', 'linestyle', '--', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        %         hold on
        
        ylim([ylim_ref(1,1), ylim_ref(1,2)])
        
        set(gca, 'fontsize', 8)
        xlabel('t (Myr)', 'fontsize', 10)
        ylabel('dz/dt (mm/yr)', 'fontsize', 10)
        title('Topographic Changes Over Time', 'fontsize', 10)
        
        h_lgnd = legend([h_entire, h_N, h_S], 'Entire Domain', 'N Basins', ...
            'S Basins', 'Weak Zone Exits', 'location', 'southwest');
        set(h_lgnd, 'fontsize', 6)
        
        set(gcf, 'renderer', 'Painters')
        
        saveas(figure(50),'dzdt_Fig.fig')
        saveas(figure(50),'dzdt_Fig.png')
        saveas(figure(50),'dzdt_Fig','epsc')
        
        mean_dz_entire_domain =  sum(dz_dt_entire_domain(2:end,1) .* time_interval);
        mean_dz_N_Basins =  sum(dz_dt_N_Basins(2:end,1) .* time_interval);
        mean_dz_S_Basins =  sum(dz_dt_S_Basins(2:end,1) .* time_interval);
        
        
        
        figure(49)
        
        h_N = plot(time_range(1,2:end) ./ 1E+06, A_m2_N_Basins(2:end,1) ./ A_m2_N_Basins(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'b', 'markersize', 5);
        hold on
        
        h_S = plot(time_range(1,2:end) ./ 1E+06, A_m2_S_Basins(2:end,1) ./ A_m2_S_Basins(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'r', 'markersize', 5);
        hold on
        
        ylim_ref = ylim;
        
        %         h_weak_zone = plot([time_for_weakzone_to_leave, time_for_weakzone_to_leave] ./ 1E+06, [ylim_ref(1,1), ylim_ref(1,2)], ...
        %             'marker', 'none', 'linestyle', '--', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        %         hold on
        
        ylim([ylim_ref(1,1), ylim_ref(1,2)])
        
        xlim_ref = xlim;
        
        plot([xlim_ref(1,1), xlim_ref(1,2)], [1, 1], ...
            'marker', 'none', 'linestyle', ':', 'linewidth', 1, 'color', 'k')
        hold on
        
        xlim([xlim_ref(1,1), xlim_ref(1,2)])
        
        set(gca, 'fontsize', 8)
        xlabel('t (Myr)', 'fontsize', 10)
        ylabel('A(t) / A(t_0)', 'fontsize', 10)
        title('N-S Drainages Over Time', 'fontsize', 10)
        
        h_lgnd = legend([h_N, h_S], 'N Basins', ...
            'S Basins', 'Weak Zone Exits', 'location', 'southwest');
        set(h_lgnd, 'fontsize', 6)
        
        set(gcf, 'renderer', 'Painters')
        
        saveas(figure(49),'N_S_Drainages_over_t_Fig.fig')
        saveas(figure(49),'N_S_Drainages_over_t_Fig.png')
        saveas(figure(49),'N_S_Drainages_over_t_Fig','epsc')
        
        
        
        figure(48)
        
        h_entire = plot(time_range(1,2:end) ./ 1E+06, Vol_m3_entire_domain(2:end,1) ./ Vol_m3_entire_domain(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        hold on
        
        h_N = plot(time_range(1,2:end) ./ 1E+06, Vol_m3_N_Basins(2:end,1) ./ Vol_m3_N_Basins(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'b', 'markersize', 5);
        hold on
        
        h_S = plot(time_range(1,2:end) ./ 1E+06, Vol_m3_S_Basins(2:end,1) ./ Vol_m3_S_Basins(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'r', 'markersize', 5);
        hold on
        
        ylim_ref = ylim;
        
        %         h_weak_zone = plot([time_for_weakzone_to_leave, time_for_weakzone_to_leave] ./ 1E+06, [ylim_ref(1,1), ylim_ref(1,2)], ...
        %             'marker', 'none', 'linestyle', '--', 'linewidth', 1, 'color', 'k');
        %         hold on
        
        ylim([ylim_ref(1,1), ylim_ref(1,2)])
        
        xlim_ref = xlim;
        
        plot([xlim_ref(1,1), xlim_ref(1,2)], [1, 1], ...
            'marker', 'none', 'linestyle', ':', 'linewidth', 1, 'color', 'k')
        hold on
        
        xlim([xlim_ref(1,1), xlim_ref(1,2)])
        
        set(gca, 'fontsize', 8)
        xlabel('t (Myr)', 'fontsize', 10)
        ylabel('V(t) / V(t_0)', 'fontsize', 10)
        title('Topographic Changes Over Time', 'fontsize', 10)
        
        h_lgnd = legend([h_entire, h_N, h_S], 'Entire Domain', 'N Basins', ...
            'S Basins', 'Weak Zone Exits', 'location', 'southwest');
        set(h_lgnd, 'fontsize', 6)
        
        set(gcf, 'renderer', 'Painters')
        
        saveas(figure(48),'Vols_over_t_Fig.fig')
        saveas(figure(48),'Vols_over_t_Fig.png')
        saveas(figure(48),'Vols_over_t_Fig','epsc')
        
        save('dz_dt_Workspace_May25.mat')
        
    end
    
    
    
    if Analyze_distrib_of_ksn_option == 1
        
        figure(51)
        
        h_min = plot(time_range(1,2:end) ./ 1E+06, min_ksn_over_time(2:end,1) ./ min_ksn_over_time(1,1), ...
            'marker', '^', 'linewidth', 1, 'color', 'b', 'markersize', 5);
        hold on
        
        h_max = plot(time_range(1,2:end) ./ 1E+06, max_ksn_over_time(2:end,1) ./ max_ksn_over_time(1,1), ...
            'marker', 's', 'linewidth', 1, 'color', 'r', 'markersize', 5);
        hold on
        
        h_mean = plot(time_range(1,2:end) ./ 1E+06, ksn_selected_excprob_over_time(2:end,1) ./ ksn_selected_excprob_over_time(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        hold on
        
        h_std = plot(time_range(1,2:end) ./ 1E+06, std_ksn_over_time(2:end,1) ./ std_ksn_over_time(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'm', 'markersize', 5);
        hold on
        
        ylim_ref = ylim;
        
        %         h_weak_zone = plot([time_for_weakzone_to_leave, time_for_weakzone_to_leave] ./ 1E+06, [ylim_ref(1,1), ylim_ref(1,2)], ...
        %             'marker', 'none', 'linestyle', '--', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        %         hold on
        
        ylim([ylim_ref(1,1), ylim_ref(1,2)])
        
        xlim_ref = xlim;
        
        plot([xlim_ref(1,1), xlim_ref(1,2)], [1, 1], ...
            'marker', 'none', 'linestyle', ':', 'linewidth', 1, 'color', 'k')
        hold on
        
        xlim([xlim_ref(1,1), xlim_ref(1,2)])
        
        h_lgnd = legend([h_min, h_max, h_mean, h_std], 'Min.', 'Max.', ...
            'Mean', 'Stan. Dev.', 'location', 'northwest');
        set(h_lgnd, 'fontsize', 6)
        
        set(gca, 'fontsize', 8)
        xlabel('t (Myr)', 'fontsize', 10)
        ylabel('k_{sn}(t) / k_{sn}(t_0)', 'fontsize', 10)
        title('Steepness over time', 'fontsize', 10)
        
        set(gcf, 'renderer', 'Painters')
        
        saveas(figure(51),'ksn_over_time_Fig.fig')
        saveas(figure(51),'ksn_over_time_Fig.png')
        saveas(figure(51),'ksn_over_time_Fig','epsc')
        
        save('ksn_Workspace_May25.mat')
        
    end
    
    
    if Analyze_distrib_of_ksn_in_strong_option == 1
        
        figure(151)
        
        h_min = plot(time_range(1,2:end) ./ 1E+06, min_ksn_in_strong_over_time(2:end,1) ./ min_ksn_in_strong_over_time(1,1), ...
            'marker', '^', 'linewidth', 1, 'color', 'b', 'markersize', 5);
        hold on
        
        h_max = plot(time_range(1,2:end) ./ 1E+06, max_ksn_in_strong_over_time(2:end,1) ./ max_ksn_in_strong_over_time(1,1), ...
            'marker', 's', 'linewidth', 1, 'color', 'r', 'markersize', 5);
        hold on
        
        h_mean = plot(time_range(1,2:end) ./ 1E+06, mean_ksn_in_strong_over_time(2:end,1) ./ mean_ksn_in_strong_over_time(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        hold on
        
        h_std = plot(time_range(1,2:end) ./ 1E+06, std_ksn_in_strong_over_time(2:end,1) ./ std_ksn_in_strong_over_time(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'm', 'markersize', 5);
        hold on
        
        ylim_ref = ylim;
        
        %         h_weak_zone = plot([time_for_weakzone_to_leave, time_for_weakzone_to_leave] ./ 1E+06, [ylim_ref(1,1), ylim_ref(1,2)], ...
        %             'marker', 'none', 'linestyle', '--', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        %         hold on
        
        ylim([ylim_ref(1,1), ylim_ref(1,2)])
        
        xlim_ref = xlim;
        
        plot([xlim_ref(1,1), xlim_ref(1,2)], [1, 1], ...
            'marker', 'none', 'linestyle', ':', 'linewidth', 1, 'color', 'k')
        hold on
        
        xlim([xlim_ref(1,1), xlim_ref(1,2)])
        
        h_lgnd = legend([h_min, h_max, h_mean, h_std], 'Min.', 'Max.', ...
            'Mean', 'Stan. Dev.', 'location', 'northwest');
        set(h_lgnd, 'fontsize', 6)
        
        set(gca, 'fontsize', 8)
        xlabel('t (Myr)', 'fontsize', 10)
        ylabel('k_{sn S}(t) / k_{sn S}(t_0)', 'fontsize', 10)
        title('k_{sn} in Strong Unit Over Time', 'fontsize', 10)
        
        set(gcf, 'renderer', 'Painters')
        
        saveas(figure(151),'ksn_in_strong_over_time_Fig.fig')
        saveas(figure(151),'ksn_in_strong_over_time_Fig.png')
        saveas(figure(151),'ksn_in_strong_over_time_Fig','epsc')
        
        save('ksn_in_strong_Workspace_May25.mat')
        
    end
    
    if Analyze_distrib_of_relief_option == 1
        
        figure(52)
        
        subplot(2,1,1)
        
        h_min = plot(time_range(1,2:end) ./ 1E+06, min_relief_window1_over_time(2:end,1) ./ min_relief_window1_over_time(1,1), ...
            'marker', '^', 'linewidth', 1, 'color', 'b', 'markersize', 5);
        hold on
        
        h_max = plot(time_range(1,2:end) ./ 1E+06, max_relief_window1_over_time(2:end,1) ./ max_relief_window1_over_time(1,1), ...
            'marker', 's', 'linewidth', 1, 'color', 'r', 'markersize', 5);
        hold on
        
        h_mean = plot(time_range(1,2:end) ./ 1E+06, relief_selected_excprob_window1_over_time(2:end,1) ./ relief_selected_excprob_window1_over_time(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        hold on
        
        h_std = plot(time_range(1,2:end) ./ 1E+06, std_relief_window1_over_time(2:end,1) ./ std_relief_window1_over_time(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'm', 'markersize', 5);
        hold on
        
        ylim_ref = ylim;
        
        %         h_weak_zone = plot([time_for_weakzone_to_leave, time_for_weakzone_to_leave] ./ 1E+06, [ylim_ref(1,1), ylim_ref(1,2)], ...
        %             'marker', 'none', 'linestyle', '--', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        %         hold on
        
        ylim([ylim_ref(1,1), ylim_ref(1,2)])
        
        xlim_ref = xlim;
        
        plot([xlim_ref(1,1), xlim_ref(1,2)], [1, 1], ...
            'marker', 'none', 'linestyle', ':', 'linewidth', 1, 'color', 'k')
        hold on
        
        xlim([xlim_ref(1,1), xlim_ref(1,2)])
        
        set(gca, 'fontsize', 8)
        
        h_lgnd = legend([h_min, h_max, h_mean, h_std], 'Min.', 'Max.', ...
            'Mean', 'Stan. Dev.', 'location', 'best');
        set(h_lgnd, 'fontsize', 6)
        
        ylabel('Relief(t) / Relief(t_0)', 'fontsize', 10)
        title(['Relief over a ' num2str(Relief_window_1_m, '%.0f') ' m window'], 'fontsize', 10)
        
        subplot(2,1,2)
        
        plot(time_range(1,2:end) ./ 1E+06, min_relief_window2_over_time(2:end,1) ./ min_relief_window2_over_time(1,1), ...
            'marker', '^', 'linewidth', 1, 'color', 'b', 'markersize', 5)
        hold on
        
        plot(time_range(1,2:end) ./ 1E+06, max_relief_window2_over_time(2:end,1) ./ max_relief_window2_over_time(1,1), ...
            'marker', 's', 'linewidth', 1, 'color', 'r', 'markersize', 5)
        hold on
        
        plot(time_range(1,2:end) ./ 1E+06, relief_selected_excprob_window2_over_time(2:end,1) ./ relief_selected_excprob_window2_over_time(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'k', 'markersize', 5)
        hold on
        
        plot(time_range(1,2:end) ./ 1E+06, std_relief_window2_over_time(2:end,1) ./ std_relief_window2_over_time(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'm', 'markersize', 5)
        hold on
        
        ylim_ref = ylim;
        
        %         h_weak_zone = plot([time_for_weakzone_to_leave, time_for_weakzone_to_leave] ./ 1E+06, [ylim_ref(1,1), ylim_ref(1,2)], ...
        %             'marker', 'none', 'linestyle', '--', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        %         hold on
        
        ylim([ylim_ref(1,1), ylim_ref(1,2)])
        
        xlim_ref = xlim;
        
        plot([xlim_ref(1,1), xlim_ref(1,2)], [1, 1], ...
            'marker', 'none', 'linestyle', ':', 'linewidth', 1, 'color', 'k')
        hold on
        
        xlim([xlim_ref(1,1), xlim_ref(1,2)])
        
        set(gca, 'fontsize', 8)
        
        title(['Relief over a ' num2str(Relief_window_2_m, '%.0f') ' m window'], 'fontsize', 10)
        xlabel('t (Myr)', 'fontsize', 10)
        ylabel('Relief(t) / Relief(t_0)', 'fontsize', 10)
        
        set(gcf, 'renderer', 'Painters')
        
        saveas(figure(52),'Relief_over_time_Fig.fig')
        saveas(figure(52),'Relief_over_time_Fig.png')
        saveas(figure(52),'Relief_over_time_Fig','epsc')
        
        save('Relief_Workspace_May25.mat')
        
    end
    
    if Analyze_distrib_of_relief_in_strong_option == 1
        
        figure(152)
        
        subplot(2,1,1)
        
        h_min = plot(time_range(1,2:end) ./ 1E+06, min_relief_window1_in_strong_over_time(2:end,1) ./ min_relief_window1_in_strong_over_time(1,1), ...
            'marker', '^', 'linewidth', 1, 'color', 'b', 'markersize', 5);
        hold on
        
        h_max = plot(time_range(1,2:end) ./ 1E+06, max_relief_window1_in_strong_over_time(2:end,1) ./ max_relief_window1_in_strong_over_time(1,1), ...
            'marker', 's', 'linewidth', 1, 'color', 'r', 'markersize', 5);
        hold on
        
        h_mean = plot(time_range(1,2:end) ./ 1E+06, mean_relief_window1_in_strong_over_time(2:end,1) ./ mean_relief_window1_in_strong_over_time(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        hold on
        
        h_std = plot(time_range(1,2:end) ./ 1E+06, std_relief_window1_in_strong_over_time(2:end,1) ./ std_relief_window1_in_strong_over_time(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'm', 'markersize', 5);
        hold on
        
        ylim_ref = ylim;
        
        %         h_weak_zone = plot([time_for_weakzone_to_leave, time_for_weakzone_to_leave] ./ 1E+06, [ylim_ref(1,1), ylim_ref(1,2)], ...
        %             'marker', 'none', 'linestyle', '--', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        %         hold on
        
        ylim([ylim_ref(1,1), ylim_ref(1,2)])
        
        xlim_ref = xlim;
        
        plot([xlim_ref(1,1), xlim_ref(1,2)], [1, 1], ...
            'marker', 'none', 'linestyle', ':', 'linewidth', 1, 'color', 'k')
        hold on
        
        xlim([xlim_ref(1,1), xlim_ref(1,2)])
        
        set(gca, 'fontsize', 8)
        
        h_lgnd = legend([h_min, h_max, h_mean, h_std], 'Min.', 'Max.', ...
            'Mean', 'Stan. Dev.', 'location', 'best');
        set(h_lgnd, 'fontsize', 6)
        
        ylabel('Relief_S(t) / Relief_S(t_0)', 'fontsize', 10)
        title(['Strong Unit Relief over a ' num2str(Relief_window_1_m, '%.0f') ' m window'], 'fontsize', 10)
        
        subplot(2,1,2)
        
        plot(time_range(1,2:end) ./ 1E+06, min_relief_window2_in_strong_over_time(2:end,1) ./ min_relief_window2_in_strong_over_time(1,1), ...
            'marker', '^', 'linewidth', 1, 'color', 'b', 'markersize', 5)
        hold on
        
        plot(time_range(1,2:end) ./ 1E+06, max_relief_window2_in_strong_over_time(2:end,1) ./ max_relief_window2_in_strong_over_time(1,1), ...
            'marker', 's', 'linewidth', 1, 'color', 'r', 'markersize', 5)
        hold on
        
        plot(time_range(1,2:end) ./ 1E+06, mean_relief_window2_in_strong_over_time(2:end,1) ./ mean_relief_window2_in_strong_over_time(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'k', 'markersize', 5)
        hold on
        
        plot(time_range(1,2:end) ./ 1E+06, std_relief_window2_in_strong_over_time(2:end,1) ./ std_relief_window2_in_strong_over_time(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'm', 'markersize', 5)
        hold on
        
        ylim_ref = ylim;
        
        %         h_weak_zone = plot([time_for_weakzone_to_leave, time_for_weakzone_to_leave] ./ 1E+06, [ylim_ref(1,1), ylim_ref(1,2)], ...
        %             'marker', 'none', 'linestyle', '--', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        %         hold on
        
        ylim([ylim_ref(1,1), ylim_ref(1,2)])
        
        xlim_ref = xlim;
        
        plot([xlim_ref(1,1), xlim_ref(1,2)], [1, 1], ...
            'marker', 'none', 'linestyle', ':', 'linewidth', 1, 'color', 'k')
        hold on
        
        xlim([xlim_ref(1,1), xlim_ref(1,2)])
        
        set(gca, 'fontsize', 8)
        
        title(['Strong Unit Relief over a ' num2str(Relief_window_2_m, '%.0f') ' m window'], 'fontsize', 10)
        xlabel('t (Myr)', 'fontsize', 10)
        ylabel('Relief_S(t) / Relief_S(t_0)', 'fontsize', 10)
        
        set(gcf, 'renderer', 'Painters')
        
        saveas(figure(152),'Relief_in_strong_over_time_Fig.fig')
        saveas(figure(152),'Relief_in_strong_over_time_Fig.png')
        saveas(figure(152),'Relief_in_strong_over_time_Fig','epsc')
        
        save('Relief_in_strong_Workspace_May25.mat')
        
    end
    
    if DIVIDEobj_Analysis == 1
        
        h_fig = figure(10);
        
        ycolor_left = [0, 0, 0];
        ycolor_right = [1, 0, 1];
        
        set(h_fig,'defaultAxesColorOrder',[ycolor_left; ycolor_right]);
        
        subplot(2,1,1)
        
        yyaxis left
        h_min = plot(time_range ./ 1E+06, min_y_dist_km_DrnDiv_OrderAboveThresh ./ min_y_dist_km_DrnDiv_OrderAboveThresh(1,1), ...
            'marker', '^', 'linewidth', 1, 'color', 'b', 'markersize', 5);
        hold on
        
        h_max = plot(time_range ./ 1E+06, max_y_dist_km_DrnDiv_OrderAboveThresh ./ max_y_dist_km_DrnDiv_OrderAboveThresh(1,1), ...
            'marker', 's', 'linewidth', 1, 'color', 'r', 'markersize', 5);
        hold on
        
        h_mean = plot(time_range ./ 1E+06, mean_y_dist_km_DrnDiv_OrderAboveThresh ./ mean_y_dist_km_DrnDiv_OrderAboveThresh(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        hold on
        
        yyaxis right
        
        h_std = plot(time_range ./ 1E+06, std_y_dist_km_DrnDiv_OrderAboveThresh ./ std_y_dist_km_DrnDiv_OrderAboveThresh(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'm', 'markersize', 5);
        hold on
        
        ylabel('std(y_{DD} / y_{DD}(t_0))', 'fontsize', 10)
        
        yyaxis left
        
        ylim_ref = ylim;
        
        %         h_weak_zone = plot([time_for_weakzone_to_leave, time_for_weakzone_to_leave] ./ 1E+06, [ylim_ref(1,1), ylim_ref(1,2)], ...
        %             'marker', 'none', 'linestyle', '--', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        %         hold on
        
        ylim([ylim_ref(1,1), ylim_ref(1,2)])
        
        set(gca, 'fontsize', 8)
        ylabel('y_{DD} / y_{DD}(t_0)', 'fontsize', 10)
        title(' Drainage Divdes'' Distance N Over Time', 'fontsize', 10)
        
        %         h_lgnd = legend([h_min, h_max, h_mean, h_std], 'Min.', 'Max.', ...
        %             'Mean', 'Stan. Dev.', 'location', 'southwest');
        %         set(h_lgnd, 'fontsize', 6)
        %
        %         h_weak_zone = plot(time_range(weak_zone_northern_y_dist_km_over_t ~= 0) ./ 1E+06, ...
        %             weak_zone_northern_y_dist_km_over_t(weak_zone_northern_y_dist_km_over_t ~= 0)./ (ymax_m / 1000), ...
        %             'marker', 'o', 'linewidth', 1.5, 'color', [0.5 0.5 0.5], 'markersize', 5);
        %         hold on
        %
        %         plot(time_range(weak_zone_southern_y_dist_km_over_t ~= 0) ./ 1E+06, ...
        %             weak_zone_southern_y_dist_km_over_t(weak_zone_southern_y_dist_km_over_t ~= 0) ./ (ymax_m / 1000), ...
        %             'marker', 'o', 'linewidth', 1.5, 'color', [0.5 0.5 0.5], 'markersize', 5)
        %         hold on
        
        subplot(2,1,2)
        
        yyaxis left
        h_min = plot(time_range ./ 1E+06, min_z_m_DrnDiv_OrderAboveThresh ./ min_z_m_DrnDiv_OrderAboveThresh(1,1), ...
            'marker', '^', 'linewidth', 1, 'color', 'b', 'markersize', 5);
        hold on
        
        h_max = plot(time_range ./ 1E+06, max_z_m_DrnDiv_OrderAboveThresh ./ max_z_m_DrnDiv_OrderAboveThresh(1,1), ...
            'marker', 's', 'linewidth', 1, 'color', 'r', 'markersize', 5);
        hold on
        
        h_mean = plot(time_range ./ 1E+06, mean_z_m_DrnDiv_OrderAboveThresh ./ mean_z_m_DrnDiv_OrderAboveThresh(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        hold on
        
        yyaxis right
        
        h_std = plot(time_range ./ 1E+06, std_z_m_DrnDiv_OrderAboveThresh ./ std_z_m_DrnDiv_OrderAboveThresh(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'm', 'markersize', 5);
        hold on
        
        ylabel('std(z_{DD} / z_{DD}(t_0))', 'fontsize', 10)
        
        yyaxis left
        
        ylim_ref = ylim;
        
        %         h_weak_zone = plot([time_for_weakzone_to_leave, time_for_weakzone_to_leave] ./ 1E+06, [ylim_ref(1,1), ylim_ref(1,2)], ...
        %             'marker', 'none', 'linestyle', '--', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        %         hold on
        
        ylim([ylim_ref(1,1), ylim_ref(1,2)])
        
        set(gca, 'fontsize', 8)
        xlabel('t (Myr)', 'fontsize', 10)
        ylabel('z_{DD} / z_{DD}(t_0)', 'fontsize', 10)
        title('Drainage Divdes'' Elevations Over Time', 'fontsize', 10)
        
        h_lgnd = legend([h_min, h_max, h_mean, h_std], 'Min.', 'Max.', ...
            'Mean', 'Stan. Dev.', 'location', 'southwest');
        set(h_lgnd, 'fontsize', 6)
        
        set(gcf, 'renderer', 'Painters')
        
        saveas(figure(10),'DrnDiv_AboveThresh_y_z_vals_over_t.fig')
        saveas(figure(10),'DrnDiv_AboveThresh_y_z_vals_over_t.png')
        saveas(figure(10),'DrnDiv_AboveThresh_y_z_vals_over_t','epsc')
        
        if Eval_DrnDivAsym == 1
            
            figure(11)
            
            yyaxis left
            
            h_min = plot(time_range ./ 1E+06, min_DivAsym_rho_Order4_DrnDiv, ...% ./ min_DivAsym_rho_Order4_DrnDiv(1,1), ...
                'marker', '^', 'linewidth', 1, 'color', 'b', 'markersize', 5);
            hold on
            
            h_max = plot(time_range ./ 1E+06, max_DivAsym_rho_Order4_DrnDiv, ...% ./ max_DivAsym_rho_Order4_DrnDiv(1,1), ...
                'marker', 's', 'linewidth', 1, 'color', 'r', 'markersize', 5);
            hold on
            
            h_mean = plot(time_range ./ 1E+06, mean_DivAsym_rho_Order4_DrnDiv, ...% ./ mean_DivAsym_rho_Order4_DrnDiv(1,1), ...
                'marker', 'o', 'linewidth', 1, 'color', 'k', 'markersize', 5);
            hold on
            
            yyaxis right
            
            h_std = plot(time_range ./ 1E+06, std_DivAsym_rho_Order4_DrnDiv, ...% ./ std_DivAsym_rho_Order4_DrnDiv(1,1), ...
                'marker', 's', 'linewidth', 1, 'color', 'm', 'markersize', 5);
            hold on
            
            set(gca, 'fontsize', 8)
            ylabel('std(DAI)', 'fontsize', 10)
            
            yyaxis left
            
            ylim_ref = ylim;
            
            %             plot([time_for_weakzone_to_leave, time_for_weakzone_to_leave] ./ 1E+06, [ylim_ref(1,1), ylim_ref(1,2)], ...
            %                 'marker', 'none', 'linestyle', '--', 'linewidth', 1, 'color', 'k', 'markersize', 5);
            %             hold on
            
            set(gca, 'fontsize', 8)
            xlabel('t (Myr)', 'fontsize', 10)
            ylabel('DAI', 'fontsize', 10)
            title('4th Order Drainage Divdes'' DAI Over Time', 'fontsize', 10)
            
            set(gcf, 'renderer', 'Painters')
            
            saveas(figure(11),'DrnDiv_AboveThresh_DAI_vals_over_t.fig')
            saveas(figure(11),'DrnDiv_AboveThresh_DAI_vals_over_t.png')
            saveas(figure(11),'DrnDiv_AboveThresh_DAI_vals_over_t','epsc')
            
        end
        
        figure(12)
        
        yyaxis left
        h_min = plot(time_range ./ 1E+06, min_Relief_m_DrnDiv_OrderAboveThresh ./ min_Relief_m_DrnDiv_OrderAboveThresh(1,1), ...
            'marker', '^', 'linewidth', 1, 'color', 'b', 'markersize', 5);
        hold on
        
        h_max = plot(time_range ./ 1E+06, max_Relief_m_DrnDiv_OrderAboveThresh ./ max_Relief_m_DrnDiv_OrderAboveThresh(1,1), ...
            'marker', 's', 'linewidth', 1, 'color', 'r', 'markersize', 5);
        hold on
        
        h_mean = plot(time_range ./ 1E+06, mean_Relief_m_DrnDiv_OrderAboveThresh ./ mean_Relief_m_DrnDiv_OrderAboveThresh(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        hold on
        
        yyaxis right
        
        
        h_std = plot(time_range ./ 1E+06, std_Relief_m_DrnDiv_OrderAboveThresh ./ std_Relief_m_DrnDiv_OrderAboveThresh(1,1), ...
            'marker', 'o', 'linewidth', 1, 'color', 'm', 'markersize', 5);
        hold on
        
        ylabel('std(z_{DD} / z_{DD}(t_0))', 'fontsize', 10)
        
        yyaxis left
        
        ylim_ref = ylim;
        
        %         h_weak_zone = plot([time_for_weakzone_to_leave, time_for_weakzone_to_leave] ./ 1E+06, [ylim_ref(1,1), ylim_ref(1,2)], ...
        %             'marker', 'none', 'linestyle', '--', 'linewidth', 1, 'color', 'k', 'markersize', 5);
        %         hold on
        
        ylim([ylim_ref(1,1), ylim_ref(1,2)])
        
        set(gca, 'fontsize', 8)
        xlabel('t (Myr)', 'fontsize', 10)
        ylabel('R_{DD} / R_{DD}(t_0)', 'fontsize', 10)
        title(['Drainage Divdes'' Relief over ' num2str(Relief_window_1_m, '%.0f') ' m'], 'fontsize', 10)
        
        h_lgnd = legend([h_min, h_max, h_mean, h_std], 'Min.', 'Max.', ...
            'Mean', 'Stan. Dev.', 'location', 'southwest');
        set(h_lgnd, 'fontsize', 6)
        
        set(gcf, 'renderer', 'Painters')
        
        saveas(figure(12),'DrnDiv_AboveThresh_Relief_vals_over_t.fig')
        saveas(figure(12),'DrnDiv_AboveThresh_Relief_vals_over_t.png')
        saveas(figure(12),'DrnDiv_AboveThresh_Relief_vals_over_t','epsc')
        
        save('Drainage_Divide_Workspace_May25.mat')
        
    end
    
    
    
    if make_elev_video_option == 1
        
        close(Vid)
        
    end
    
    
    
    if make_elev_range_over_t_graph == 1
        
        figure(2)
        
        set(gca, 'fontsize', 10)
        
        xlabel('t (Myr)', 'fontsize', 12)
        ylabel('z (m)', 'fontsize', 12)
        
        h_lgnd = legend([h_min, h_mean, h_max], 'Minimum', 'Mean', 'Maximum', ...
            'location', 'best');
        
        set(h_lgnd, 'fontsize', 10)
        
        set(gcf, 'renderer', 'Painters')
        
        saveas(figure(2), [fileprefix 'min_max_mean_z_over_t.fig'])
        saveas(figure(2),[fileprefix 'min_max_mean_over_t.png'])
        
    end
    
    
    
    if Analyze_Stream_Orientations == 1
        
        figure(3)
        
        set(gca, 'fontsize', 12)
        
        xlabel('Orientation (degrees)', 'fontsize', 14)
        ylabel({'Fraction of Stream Nodes at time t / ', ...
            'Fraction of Stream Nodes at time t_0'}, 'fontsize', 14)
        
        xlim([angle_min angle_max])
        
        h = colorbar;
        colormap(time_colors)
        ylabel(h, 't (Myr)', 'fontsize', 12)
        caxis([min(time_range) max(time_range)])
        
        set(gcf, 'renderer', 'Painters')
        
        saveas(figure(3),'Stream_Orientations_over_t.fig')
        saveas(figure(3),'Stream_Orientations_over_t.png')
        saveas(figure(3),'Stream_Orientations_over_t','epsc')
        
        save('Stream_Orientations_Workspace_May25.mat')
        
    end
    
    close all
    
end